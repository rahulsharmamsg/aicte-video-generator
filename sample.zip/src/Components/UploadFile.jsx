import React, { useContext, useEffect, useState, useRef} from "react";
import { Modal, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import Webcam from "react-webcam";
import VideoRecorder from "./VideoRecorder";
import {Progress} from 'react-sweet-progress'

import { VideoCamera } from "phosphor-react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { AppContext } from "../context.js";
import ReactPlayer from "react-player";
function UploadFile() {
  const [show, setShow] = useState(false);
  const [videoorigin, setVideoorigin] = useState(0);
  const [videourl, setVideourl] = useState(0);
  const [video, setVideo] = useState();
  const [Recordedvideo, setRecordedVideo] = useState();
  const [isRecording, setIsRecording] = useState(false);
  const [recordedChunks, setRecordedChunks] = useState([]);
  const [timer, settimer] = useState(100);
  const webcamRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const handleClose = () => setShow(false);
  const handleShow = () => {
    setShow(true);
  };
  let navigate = useNavigate();
  const { setVideoData } = useContext(AppContext);
  const handleSubmit = () => {

    let forms = JSON.parse(localStorage.getItem("videodata"));
    console.log("formdata=", forms);

    let formData = new FormData();
    formData.append("file", video);
    formData.append("state", forms.State);
    formData.append("uniqueId", forms.Uid);
    formData.append("district", forms.district);
    formData.append("school", forms.schoolname);
    formData.append("name", forms.stname);
    formData.append("contact", forms.stnum);
    formData.append("email", forms.stemail);
    formData.append("tone", "positive" );
    formData.append("tokens", "positive" );
    axios
      .post("http://localhost:8090/upload_vid", formData, {})
      .then((res) => {
        if (res.data.status == "success") {
          localStorage.setItem("reasponse", JSON.stringify(res.data.result));
          navigate("/AiDiscription");
        }
      })
      .catch((err) => {
        console.log(err, `error`);
      });
  };
  function checkVideoDuration(file) {
    var video = document.createElement("video");
    video.preload = "metadata";
    video.onloadedmetadata = function () {
      window.URL.revokeObjectURL(video.src);
      var duration = video.duration;
      if (duration <= 20) {
        console.log("Video is less than or equal to 15 seconds long");
      } else {
        alert("Video is longer than 15 seconds");
        setVideourl()
        setVideo()
      }
    };
    video.src = URL.createObjectURL(file);
  }

  const handleFile = (e) => {
    let files = e.target.files;
    if (files.length === 1) {
      let file = files[0];
      setVideourl(URL.createObjectURL(file));
      setVideo(file)
      checkVideoDuration(file);
    }

    let allowedExtensions = ["webm", "mp4"];
    if (!allowedExtensions.includes(e.target.files[0].type.split("/")[1])) {
      alert("Only webm,mp4 Video file allowed");
      e.target.files[0] = "";
    } else {
      setVideo(e.target.files[0]);
    }
  };
  useEffect(() => {
    setVideoorigin(1);
    setRecordedVideo(localStorage.getItem("recordedVideo"));
  }, [videourl]);
  const handleStartRecording = () => {
    setIsRecording(true);
    setRecordedChunks([]);
    Countdown()

    const stream = webcamRef.current.stream;
    mediaRecorderRef.current = new MediaRecorder(stream);

    mediaRecorderRef.current.ondataavailable = event => {
      if (event.data.size > 0) {
     
        setRecordedChunks(prevChunks => [...prevChunks, event.data]);
        // setVideoData(prevChunks => [...prevChunks, event.data]);
      }
    };

    mediaRecorderRef.current.start();
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      ShareData();

    }
  };

  const handleDownload = () => {
    const blob = new Blob(recordedChunks, { type: 'video/mp4' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    // a.download = 'recorded-video.mp4';
    document.body.appendChild(a);
    setVideourl(url)

    // a.click();
    // window.URL.revokeObjectURL(url);
    // document.body.removeChild(a);
  };
  const ShareData = () => {
    const blob = new Blob(recordedChunks, { type: 'video/mp4' });
    const url = URL.createObjectURL(blob);
    setVideoData(url);
    checkVideoDuration(url)
 
     
  };
  const Countdown = () => {
    let i = 100;
    let interval = setInterval(() => {
        settimer(i)
        i--;
        if (i < 0) {
            clearInterval(interval);
            handleStopRecording()
        }
    }, 150);
  }
  return (
    <>
      <main className="contentarea">
        <div className="banner-allpage-sec">
          <ul className="breadcrumb">
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>Video</li>
            <li>Branding</li>
          </ul>
          <div className="banner-content-sec text-center">
            <h1 className="first-head">AI Video Analyzer</h1>
            <h3 className="second-head">
              Fast, simple and easy to use tool you'll love.
            </h3>
            <br />
          </div>
        </div>
        <section className="selectlang">
          <div className="container">
            <div className="row">
              <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                <div className="uploadFile useBorder">
                  <div class="upload-btn-wrapper">
                    <a
                      class="button orange btn"
                      href="/PassportPhotoMaker"
                      style={{
                        fontSize: 26,
                        borderRadius: 10,
                        padding: "15px 30px",
                      }}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="32"
                        height="32"
                        fill="currentColor"
                        viewBox="0 0 256 256"
                      >
                        <rect width="256" height="256" fill="none"></rect>
                        <polyline
                          points="86 82 128 40 170 82"
                          fill="none"
                          stroke="currentColor"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                        ></polyline>
                        <line
                          x1="128"
                          y1="152"
                          x2="128"
                          y2="40"
                          fill="none"
                          stroke="currentColor"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                        ></line>
                        <path
                          d="M216,152v56a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V152"
                          fill="none"
                          stroke="currentColor"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="16"
                        ></path>
                      </svg>
                      Upload Video
                    </a>
                    <input
                      type="file"
                      name="myfile"
                      onChange={(e) => handleFile(e)}
                    />
                  </div>
                </div>
              </div>
              <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                <div className="useBorder">
                  <Button variant="primary" onClick={handleShow}>
                    <VideoCamera size={28} /> Record
                  </Button>
                  <Modal show={show} onHide={handleClose}>
                    <Modal.Header closeButton>
                      <Modal.Title>Recording</Modal.Title>
                    </Modal.Header>
                    <Modal.Body className="p-3 text-center">
                      {/* <VideoRecorder  /> */}
                      <Webcam
                        audio={false}
                        mirrored={true}
                        ref={webcamRef}
                        videoConstraints={{
                          width: 1280,
                          height: 720,
                          facingMode: "user",
                        }}
                      />

                      {isRecording ? (
                        <>
                          <Progress percent={timer} />
                          <button
                            className="button orange"
                            onClick={handleStopRecording}
                          >
                            Stop Recording
                          </button>
                        </>
                      ) : (
                        <button
                          className="button green"
                          onClick={handleStartRecording}
                        >
                          Start Recording
                        </button>
                      )}

                      {recordedChunks.length > 0 && (
                        <button
                          className="button orange"
                          style={{ marginLeft: 10 }}
                          onClick={handleDownload}
                        >
                          Upload Recording
                        </button>
                      )}
                    </Modal.Body>
                  </Modal>
                </div>
              </div>
            </div>

            {videourl && (
              <div className="mt-4">
                {/* <ReactPlayer url={[
     {src: videourl.videoFileURL, type: 'video/mp4'}
 
   ]} />
   */}
                <div className="max-width-800 m-auto">
                  <video
                    src={videourl}
                    typeof="video/mp4"
                    autoPlay={true}
                    controls={true}
                    duta
                  />
                </div>
              </div>
            )}
            <div className="mt-4">
              <Button
                type="button"
                className="button green"
                onClick={handleSubmit}
              >
                Submit
              </Button>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}

export default UploadFile;
