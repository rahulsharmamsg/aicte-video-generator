import React, { useState } from 'react'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'
import { UploadSimple } from 'phosphor-react'
// import original from "../assets/images/upload/background/original.jpg"
import result from "../assets/images/upload/background/result.png"
import { Link } from 'react-router-dom'
import removebg from "../assets/images/image/background/1-1.jpg"
import removebg2 from "../assets/images/image/background/1.jpg"
import removebg3 from "../assets/images/image/background/2.jpg"

function ImageBackgroundRemover() {
  const [imgBg, setImgBg] = useState(false);
  const [file, setFile] = useState();

 const HandleBg = (e) =>{
    const binarydata = [];
    binarydata.push(e.target.files[0]);
    setFile(URL.createObjectURL(new Blob(binarydata, {type: "application/zip"})));
    if(e.target.files[0]){
        setImgBg(true);
    }
  
 }
  return (
    <>
      <div className="banner-allpage-sec" style={{paddingBottom:100}}>
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Image</li>
            <li>Image Background Remover</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Image Background Remover</h1>
            <h3 className="second-head">Fast, simple and easy to use tool you'll love.</h3>
            <br/>
            <div className='upload-btn-wrapper'>
            <Link to="" className="button orange btn" style={{fontSize:26, borderRadius:10, padding:"15px 30px"}}>
            {/* <UploadSimple size={32} /> */}
                Coming soon...
            </Link>
            {/* <input type="file" name='myFile' onChange={HandleBg} /> */}
            </div>
            {/* <p className="txt-eg">or drop a file here CTRL+V to paste image or URL</p> */}
        </div>
    </div>
    {imgBg? 
    <section style={{textAlign:"center", marginTop:-100, position:"relative"}}>
        <div className="page-container">
            <div className="originalResultDiv">               
                <button type="button" aria-label="Close" onClick={()=> setImgBg(!imgBg)} className="clsoriginalResultDiv">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fillRule="evenodd" clipRule="evenodd" d="M4.818 4.05a.75.75 0 0 0-1.06 1.06l3.181 3.183-3.182 3.182a.75.75 0 1 0 1.061 1.06L8 9.355l3.182 3.182a.75.75 0 1 0 1.06-1.061L9.062 8.293l3.182-3.182a.75.75 0 0 0-1.061-1.06L8 7.231 4.818 4.05Z" fill="currentColor"></path>
                    </svg>
                </button>            
                <div className="row">
                    <div className="col-lg-4">
                        <h4>Original</h4>
                        <div className="imgDiv">
                            <img src={file} crossorigin="anonymous" alt="original"/>
                        </div>
                    </div>
                    <div className="col-lg-4">
                        <h4>Result</h4>
                        <div className="imgDiv">
                            <img src={result} alt="edit picture" oncontextmenu="return false" crossorigin="anonymous"/>
                        </div>
                    </div>
                    <div className="col-lg-4">                       
                        <div className="optRadioDiv">
                            <div className="optRadioRd">
                                <input checked="true" id="input-312" role="radio" type="radio" name="radio-311" value="PNG"/>
                                <label for="input-312" className="v-label theme--light">PNG</label>
                            </div>
                            <div className="optRadioRd">
                                <input  id="input-315" role="radio" type="radio" name="radio-311" value="PNG"/>
                                <label for="input-315" className="v-label theme--light">JPG</label>
                            </div>
                        </div>
                        <button className="button orange dwnLoadBtn">
                            <svg xmlns="http://www.w3.org/2000/svg" width="28px" height="28px" style={{rotate:"90deg", position:"relative", top:6}} fill="currentColor" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"></rect><polyline points="94 170 136 128 94 86" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="16"></polyline><line x1="24" y1="128" x2="136" y2="128" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="16"></line><path d="M136,40h56a8,8,0,0,1,8,8V208a8,8,0,0,1-8,8H136" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="16"></path></svg>
                            Download
                        </button>
                        <p class="txt-eg2">Preview Image 395 x 632, free</p>
                        <Link to="/Editor/ImageEditor" class="txtOpenEdtr">
                            <img src="images/color-plate-svgrepo-com.svg" alt="" width="18px"/> Open in Editor
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    </section>
:null}
    <section style={{textAlign:"center", marginTop:-25, position:"relative"}}>
        <div className="secIBRImg">
            <img src={removebg} alt="window" width="480" height="340"/> 
            
        </div>
    </section>
    <section className="features-homepage-sec">
            <div className="page-container">
                <div className="features-content-sec main-container">
                    <div className="feature-box-sec row">
                        <div className="col-lg-6">
                            <h4 className="feature-name-head">Remove Background from Image Effortlessly</h4>
                            <p>Removing background from an image has never been easier with our AI background eraser. You can make background transparent and create stunning visuals in no time. It’s the best bg remover and png maker.</p>                            
                        </div>
                        <div className="col-lg-6">
                            <img src={removebg3} alt=""/>
                        </div>
                    </div>
                    <div className="feature-box-sec row">
                        <div className="col-lg-6">
                        <img src={removebg2} alt=""/>
                        
                        </div>
                        <div className="col-lg-6">
                            <h4 className="feature-name-head">Change Background to Unleash Your Creativity</h4>
                            <p>Our free background remover is a powerful tool designed to help you change the background of your images effortlessly. With its advanced algorithms, you can quickly remove the background of any image and replace it with a new one.</p>
                            
                        </div>                
                    </div>
                </div>
            </div>
        </section>
    <Safe/>
    <WhyChoose/>
    {/* <Faq/> */}
    </>
  )
}

export default ImageBackgroundRemover
