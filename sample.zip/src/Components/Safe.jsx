import React from 'react'
import benefit1 from "../assets/images/benefit_1.png";
import benefit2 from "../assets/images/benefit_2.png";
import benefit3 from "../assets/images/benefit_3.png";

const Safe = () => {
  return (
    <>
      <div className="page-container logo-maker-page">
        <section>
            <h2 className="text-center">SMARTER. FASTER. EASIER.</h2>
            <br/><br/><br/>
            {/* <div className="row text-center sfe-sec">
                <div className="col-lg-4">
                    <div className="box">
                        <img src={benefit1} alt="SMARTER"/>
                        <h3>Smarter</h3>
                        <strong>Uses proprietary AI technology</strong> 
                        <p>Designsthan uses machine learning to simplify your creative workflow. Less Manual work, more time to focus on the bigger picture.</p>   
                    </div>        
                </div>
                <div className="col-lg-4">
                    <div className="box">
                        <img src={benefit2} alt="SMARTER"/>
                        <h3>Faster</h3>
                        <strong>Exceptional results in less than 2 minutes</strong> 
                        <p>Create full marketing campaigns in only 2 minutes with artificial intellugence. Quicker creation time, more clients and revenue.</p> 
                    </div>          
                </div>
                <div className="col-lg-4">
                    <div className="box">
                        <img src={benefit3} alt="SMARTER"/>
                        <h3>Easier</h3>
                        <strong>Intuitive and accessible to all</strong> 
                        <p>With its intuitive user experience, Designsthan make design accessible. You can create stunning visual content even as a beginner.</p> 
                    </div>         
                </div>
            </div> */}
        </section>
     </div>
    </>
  )
}

export default Safe
