import React from 'react'
import { Link } from 'react-router-dom'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const MultiCameraRecording = () => {
  return (
    <>
    <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Meeting</li>
            <li>Multi-Camera Recording</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Multi-Camera Recording</h1>
            <h3 className="second-head">Create professional multi-camera videos with Visla's easy tools. Record from two camera sources simultaneously, add mobile as a second camera, and showcase both angles in one video.</h3>
        </div>
    </div>
    <section style={{textAlign:"center", marginTop:-100, position:"relative"}}>
        <div className="secPassportPhotoImg">
            <img src="./assets/images/multi-camera-recording/Multi Camera Recording-1.png" alt="window" width="480"/>             
        </div>
        <div className="page-container passportPhotoSection">
            <div className="features">
                <div className="margin">
                 
                    <br/> <br/>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                                
                                <div className="flexCenter col-sm-12 col-md-12 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Record from multiple angles</p>
                                    <p className="chunkDescription">
                                        Visla allows you to simultaneously record from two camera sources in a combined layout. Add a second camera to record from another angle or serve as a document camera. There is no need for post-production to sync up different angles as you can showcase both camera views at the same time in your video recording.
                                    </p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <br/><br/><br/><br/>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Add mobile as a second camera</p>
                                    <p className="chunkDescription">Don’t have a fancy multi-camera set-up in your office? With Visla, there is no need for fancy equipments to achieve studio production quality. Visla allows you to simply connect your phone as a second camera so that you can get both the webcam view and the mobile camera that serves as a second angle.</p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="./assets/images/multi-camera-recording/Multi Camera Recording-2.png" alt="" width="100%" className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
        </div>
    </section>
    <Safe/>
    <WhyChoose/>
    </>
  )
}

export default MultiCameraRecording