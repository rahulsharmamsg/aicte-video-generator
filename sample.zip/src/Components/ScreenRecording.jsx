import React from 'react'
import { Link } from 'react-router-dom'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const ScreenRecording = () => {
  return (
    <>
     <div class="banner-allpage-sec">
        <ul class="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Meeting</li>
            <li>Screen Recording</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Screen Recording</h1>
            <h3 className="second-head">Free screen recorder perfect for work, school, and personal use. Easily record your screen and camera with audio. With Anuvadini's free desktop and mobile apps, make high-quality tutorials, walkthroughs, meeting recording, or demos to take your screen recording to the next level.</h3>
        </div>
    </div>
    <section style={{textAlign:"center", marginTop:-100, position:"relative"}}>
        <div className="secPassportPhotoImg">
            <img src="./assets/images/screen-recording/Record-Meetings.png" alt="window" width="480"/>            
        </div>
    </section>
    <section>
        <div className="page-container passportPhotoSection">
            <div className="features">
                <div className="margin">
                    <h2>Anuvadini makes screen recording simple</h2>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                                <div className="col-sm-12 col-md-6 col-12">
                                    <div className="relative"><img src="./assets/images/screen-recording/Easily-share-your-screen-1.png" alt="" width="100%"  className="clearImg"/></div>
                                </div>
                                <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Adjust Camera Layout</p>
                                    <p className="chunkDescription">Show yourself while also recording your screen! Easily adjust the size, position, and layout of your camera overlay.</p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Select Region</p>
                                    <p className="chunkDescription">Select a preset ratio or draw any custom region and start recording.</p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="./assets/images/screen-recording/Easily-share-your-screen-2.png" alt="" width="100%" className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="../assets/images/screen-recording/Easily-share-your-screen-2.png" alt="" width="100%" className="clearImg"/></div>
                            </div>
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Record Computer Sound</p>
                                    <p className="chunkDescription">Capture your internal system audio along with your microphone.</p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Edit and Share</p>
                                    <p className="chunkDescription">Effortlessly edit your recordings and share them with an instantly sharable link.</p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="../assets/images/screen-recording/Easily-share-your-screen-4.png" alt="" width="100%"  className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <br /><br /><br /><br />
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="../assets/images/screen-recording/Screen-Capture-1.png" alt="" width="100%" className="clearImg"/></div>
                            </div>
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Power up communication for workplace</p>
                                    <p className="chunkDescription">Use the screen recording function if you have to demonstrate a specific program or function as part of your job. You can also use it for onboarding new employees and for sending them tutorials or instructional videos. Demonstrating products to customers or keeping track of how you do certain tasks using the software is easy. With Anuvadini, you don't have to spend time and effort recording your screen; just click, select your screen, and start recording.</p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <br /><br /><br />
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Record Meetings with Anuvadini’s Screen Recording</p>
                                    <p className="chunkDescription">Anuvadini provides an effective tool for recording your meetings, writing down meeting notes, and extracting highlights from these meetings, thereby increasing productivity by transforming long form contents into succinct snippets. What's more - Anuvadini will automatically transcribe all the recorded clips.</p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="../assets/images/screen-recording/Record-Meetings.png" alt="" width="100%"  className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
        </div>
    </section>
    <Safe/>
    <WhyChoose/>
    </>
  )
}

export default ScreenRecording