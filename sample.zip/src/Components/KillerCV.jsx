import React from 'react'

function KillerCV() {
  return (
    <>
      
    </>
  )
}

export default KillerCV
