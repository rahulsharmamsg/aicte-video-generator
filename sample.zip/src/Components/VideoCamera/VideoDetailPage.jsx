import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Table, Tab, Tabs } from "react-bootstrap";
import axios from "axios";
import { Progress } from "react-sweet-progress";
function VideoDetailPage() {
  const [key, setKey] = useState("shortlist");
  const [response, setResponse] = useState([]);
  const [shortresponse, setshortResponse] = useState([]);

  useEffect(() => {
    let token = localStorage.getItem('jwt-token')
    axios
      .get("http://localhost:8090/fetch_all_vid",{ headers: {"Authorization" : `Bearer ${token?token:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoidml2IiwidXNlck5hbWUiOiJ2aXZAbWFpbC5jb20iLCJyb2xlIjoiYWRtaW4iLCJpYXQiOjE2OTIxNzU3NDgsImV4cCI6MTY5MjI2MjE0OH0.p3evEbjzrTYqLSJaD0kEe3OO40Co_dqmzNUnAJRA7Hk"}`} })
      .then((res) => {
        if (res.data.status == "success") {
          
          let data = res.data.data
          console.log(data)
          setResponse(data.videos);
        }
      })
      .catch((err) => {
        console.log(err, `error`);
      });
    axios.get("http://localhost:8090/fetch_shortlisted_vid",{ headers: {"Authorization" : `Bearer ${token?token:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoidml2IiwidXNlck5hbWUiOiJ2aXZAbWFpbC5jb20iLCJyb2xlIjoiYWRtaW4iLCJpYXQiOjE2OTIxNzU3NDgsImV4cCI6MTY5MjI2MjE0OH0.p3evEbjzrTYqLSJaD0kEe3OO40Co_dqmzNUnAJRA7Hk"}`} })
    .then((res)=>
    {
      if (res.data.status == "success") {
        
        let data = res.data.data
        console.log(data)
        setshortResponse(data.videos);
      }
    })
  }, []);
  const handleShortlist = (id) => {
    alert("id: " + id)
    axios.post("http://localhost:8090/set_shortlisted").then((res)=>{
      if (res.data.status == "success"){
        alert("sucessfully shortlisted")
      }
      else alert("something went wrong")
    }).catch((err)=>{
      console.log("shortlist apii",err)
    })
  }
  return (
    <>
      <div className="banner-allpage-sec">
        <ul className="breadcrumb">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>Video</li>
          <li>AI Video Analyzer</li>
        </ul>
        <div className="banner-content-sec text-center">
          <h1 className="first-head">AI Video Analyzer</h1>
          <h3 className="second-head">
            Fast, simple and easy to use tool you'll love.
          </h3>
          <br />
        </div>
      </div>
      <main className="contentarea">
        <section className="vidpage">
          <div className="container">
            <div className="selectstate d-flex justify-content-start">
              <select className="form-select">
                <option value="0">Select State</option>
                <option value="1">Uttar Pradesh</option>
                <option value="1">Uttar Pradesh</option>
                <option value="1">Uttar Pradesh</option>
                <option value="1">Uttar Pradesh</option>
              </select>
              <select className="form-select">
                <option value="0">Select District</option>
                <option value="1">Agra</option>
                <option value="1">Jaunpur</option>
                <option value="1">Prayagraj</option>
                <option value="1">Uttar Pradesh</option>
              </select>
            </div>
            <div className="videoTab text-start">
              <Tabs
                id="controlled-tab-example"
                activeKey={key}
                onSelect={(k) => setKey(k)}
                className="mb-3"
              >
                <Tab eventKey="shortlist" title="Shortlist">
                  <div className="tabDiv ">
                  {shortresponse?.map((item, index) => {
                      return (
                        <>
                          <div className="tabDetail mt-4 d-flex justify-content-between align-items-center">
                            <div className="videos">
                              <video
                                width="320"
                                height="240"
                                src={`http://localhost:8090/${item?.path}`}
                                controls
                              ></video>
                            </div>
                            <div className="tabledata">
                              <Table responsive className="text-start">
                                <tbody>
                                  <tr>
                                    <td>Unique ID</td>
                                    <td>{item.uniqueId}</td>
                                    <td>State</td>
                                    <td>{item.state}</td>
                                  </tr>
                                  <tr>
                                    <td>Student Name</td>
                                    <td>{item.name}</td>
                                    <td>District</td>
                                    <td>{item.district}</td>
                                  </tr>
                                  <tr>
                                    <td>Contact</td>
                                    <td>{item.contact}</td>
                                    <td>School Name</td>
                                    <td>{item.school}</td>
                                  </tr>
                                  <tr>
                                    <td>Email:</td>
                                    <td colSpan={3}>{item.email}</td>
                                  </tr>
                                  <tr>
                                    <td>Emotion</td>
                                    <td colSpan={3}>
                                      <ul>
                                        <li className="d-flex justify-content-between">
                                          <span title="surprice">😲</span>{" "}
                                          <Progress
                                            percent={Math.floor(item.percentage.surprise)}
                                          />
                                        </li>
                                        <li className="d-flex justify-content-between">
                                          <span title="Happy">😁</span>{" "}
                                          <Progress
                                            percent={Math.floor(item.percentage.happy)}
                                          />{" "}
                                        </li>
                                        <li className="d-flex justify-content-between">
                                          <span title="Nutral">🙂</span>{" "}
                                          <Progress
                                            percent={(Math.floor(item.percentage.neutral))}
                                          />{" "}
                                        </li>
                                        <li className="d-flex justify-content-between">
                                          <span title="Sad">😔</span>{" "}
                                          <Progress
                                            percent={Math.floor(item.percentage.sad)}
                                          />
                                        </li>
                                        <li className="d-flex justify-content-between">
                                          <span title="angry">🥹</span>{" "}
                                          <Progress
                                            percent={Math.floor(item.percentage.angry)}
                                          />
                                        </li>
                                        <li className="d-flex justify-content-between">
                                          <span title="fear">😱</span>{" "}
                                          <Progress
                                            percent={Math.floor(item.percentage.fear)}
                                          />
                                        </li>
                                      </ul>
                                    </td>
                                  </tr>
                                </tbody>
                              </Table>
                            </div>
                            <div className="totalScore">
                              <p>Confidence Score</p>
                              <h2>{Math.floor(item.percentage.percentage)+'%'}</h2>
                              <div className="mt-5">
                                <input
                                  type="checkbox"
                                  className="formcontrol"
                                  id="select"
                                  checked={item.status=='shorlisted'?true:false}
                                  onClick={()=>handleShortlist(item._id)}
                                />
                                <label htmlFor="select">
                                  Select to Shortlist
                                </label>
                              </div>
                            </div>
                          </div>
                        </>
                      );
                    })}
                
                  </div>
                </Tab>
                <Tab eventKey="pendding" title="Pendding">
                  <div className="tabDiv">
                    {response?.map((item, index) => {
                      return (
                        <>
                          <div className="tabDetail mt-4 d-flex justify-content-between align-items-center">
                            <div className="videos">
                              <video
                                width="320"
                                height="240"
                                src={`http://localhost:8090/${item?.path}`}
                                controls
                              ></video>
                            </div>
                            <div className="tabledata">
                              <Table responsive className="text-start">
                                <tbody>
                                  <tr>
                                    <td>Unique ID</td>
                                    <td>{item.uniqueId}</td>
                                    <td>State</td>
                                    <td>{item.state}</td>
                                  </tr>
                                  <tr>
                                    <td>Student Name</td>
                                    <td>{item.name}</td>
                                    <td>District</td>
                                    <td>{item.district}</td>
                                  </tr>
                                  <tr>
                                    <td>Contact</td>
                                    <td>{item.contact}</td>
                                    <td>School Name</td>
                                    <td>{item.school}</td>
                                  </tr>
                                  <tr>
                                    <td>Email:</td>
                                    <td colSpan={3}>{item.email}</td>
                                  </tr>
                                  <tr>
                                    <td>Emotion</td>
                                    <td colSpan={3}>
                                      <ul>
                                        <li className="d-flex justify-content-between">
                                          <span title="surprice">😲</span>{" "}
                                          <Progress
                                            percent={Math.floor(item.percentage.surprise)}
                                          />
                                        </li>
                                        <li className="d-flex justify-content-between">
                                          <span title="Happy">😁</span>{" "}
                                          <Progress
                                            percent={Math.floor(item.percentage.happy)}
                                          />{" "}
                                        </li>
                                        <li className="d-flex justify-content-between">
                                          <span title="Nutral">🙂</span>{" "}
                                          <Progress
                                            percent={(Math.floor(item.percentage.neutral))}
                                          />{" "}
                                        </li>
                                        <li className="d-flex justify-content-between">
                                          <span title="Sad">😔</span>{" "}
                                          <Progress
                                            percent={Math.floor(item.percentage.sad)}
                                          />
                                        </li>
                                        <li className="d-flex justify-content-between">
                                          <span title="angry">🥹</span>{" "}
                                          <Progress
                                            percent={Math.floor(item.percentage.angry)}
                                          />
                                        </li>
                                        <li className="d-flex justify-content-between">
                                          <span title="fear">😱</span>{" "}
                                          <Progress
                                            percent={Math.floor(item.percentage.fear)}
                                          />
                                        </li>
                                      </ul>
                                    </td>
                                  </tr>
                                </tbody>
                              </Table>
                            </div>
                            <div className="totalScore">
                              <p>Confidence Score</p>
                              <h2>{Math.floor(item.percentage.percentage)+'%'}</h2>
                              <div className="mt-5">
                                <input
                                  type="checkbox"
                                  className="formcontrol"
                                  id="select"
                                  onClick={()=>handleShortlist(item._id)}
                                />
                                <label htmlFor="select">
                                  Select to Shortlist
                                </label>
                              </div>
                            </div>
                          </div>
                        </>
                      );
                    })}

                 
                  </div>
                </Tab>
              </Tabs>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}

export default VideoDetailPage;
