import React from "react";
import { Link } from "react-router-dom";
import Faq from "./Faq";
import Safe from "./Safe";
import WhyChoose from "./WhyChoose";

const VoiceTextToTextImageToTextTranslation = () => {
  return (
    <>
      <div className="banner-allpage-sec">
        <ul className="breadcrumb">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>Voice</li>
          <li>Voice: Text to Text, Image to Text Translation</li>
        </ul>
        <div className="banner-content-sec text-center">
          <h1 className="first-head">
            Voice: Text to Text, Image to Text Translation
          </h1>
          <h3 className="second-head"></h3>
        </div>
      </div>
      <Safe/>
      <WhyChoose/>
      <Faq/>
    </>
  );
};

export default VoiceTextToTextImageToTextTranslation;
