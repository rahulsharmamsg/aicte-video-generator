import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const OnlineDocumentTranslationTool = () => {
  return (
    <>
    <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Translation</li>
            <li>Online Document Translation Tool including Online Editor</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Online Document Translation Tool including Online Editor</h1>
            <h3 className="second-head"></h3>
        </div>
    </div>
    <Safe/>
    <WhyChoose/>
    <Faq/>
    </>
  )
}

export default OnlineDocumentTranslationTool