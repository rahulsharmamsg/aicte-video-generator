import React, { useEffect, useState } from 'react';
import svgfilecookie from "../../assets/images/cookies.svg";
import Cookies from 'js-cookie';
function CookiesSection() {
    // const [acceptedCookies, setAcceptedCookies] = useState(!Cookies.get('cookiesAccepted'))
    // const handleAcceptCookies = () => {
    //     Cookies.set('cookiesAccepted', 'true', { expires: 1 / 60 }); // Store the user's consent for one year
    //     setAcceptedCookies(true);
    //   };
    
    //   if (acceptedCookies) {
    //     return null; // If the user has accepted cookies, don't show the popup
    //   }
    const [showAlert, setShowAlert] = useState(0);

    function setAlertTimer() {
        setTimeout(function () {
          setShowAlert(1)
        }, 10000); // 10 seconds in milliseconds
      }
      
      useEffect(() => {
        setShowAlert(0)
      
        return () => {
            setAlertTimer();
        }
      }, [])
      
      
      
      
 
  return (
    <>
     {showAlert==1?<div className="cookies-section">
       
          <img src={svgfilecookie} width={70} className="m-r-1r"/>{" "}
          <span className="m-r-1r">We use cookies to give you a better experience.</span>
          <button className="button green m-r-1r" onClick={()=>setShowAlert(2)}>Sweet!</button>
          <button className="button secondary" onClick={()=>setShowAlert(2)}>Sorry, I’m on a diet</button>
        
      </div>
        :null}
    </>
  );
}

export default CookiesSection;
