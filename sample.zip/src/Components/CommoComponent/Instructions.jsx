import React from "react";
import './instructions.css'
function Instructions({ type }) {
  return (
    <>
      {type == "audio" ? (
        <>
           <div className="page-instruction-section">
            <h3>Instructions:</h3>
            <ul>
              <li>Upload the file (supported file format .wav) or record from the page</li>
              <li>You will see a preview of the file which was uploaded/Recorded</li>
              <li>Change the parameters as requrired and click on submit</li>
              <li>Compare the Result with the given file on the screen</li>
              <li>Click on download to finish!</li>
            </ul>
         
          </div>
        </>
      ) : null}
    </>
  );
}

export default Instructions;
