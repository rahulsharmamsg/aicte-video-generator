import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'
import { UploadSimple } from 'phosphor-react'

const VideowithVoice = () => {
  return (
    <>
     <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Video</li>
            <li>Video with Voice</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Video with Voice</h1>
            <h3 className="second-head">Fast, simple and easy to use tool you'll love.</h3>
            <br/>
            <Link to="" className="button orange btn" style={{fontSize:26, borderRadius:10, padding:"15px 30px"}}>
            {/* <UploadSimple size={32} /> */}
                Coming soon...
            </Link>
            
            {/* <p className="txt-eg">or drop a file here CTRL+V to paste image or URL</p> */}
        </div>
    </div>
    <Safe/>
    <WhyChoose/>
    <Faq/>
    </>
  )
}

export default VideowithVoice