import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BsFiletypePdf } from "react-icons/bs";
import { useNavigate } from 'react-router-dom';
import { AiOutlineFileAdd } from "react-icons/ai";
import { ArrowLeft, } from 'phosphor-react';
import Pdfurl from './pdfurl';
import { useEffect } from 'react';

const FileUpload = () => {
  const [file, setFile] = useState([]);
  const [fileURL, setFileURL] = useState([]);
  const [hidediv, setHidediv] = useState(0);
  const [IsHide, setIsHide] = useState(0);
  const [pdfDataUrl, setPdfDataUrl] = useState("");
  const [outputpdf, setoutputpdf] = useState();

  const handleFileChange = (event) => {
    const selectedFiles = event.target.files;
    const fileObjectURLs = [];

    for (const file of selectedFiles) {
      const fileObjectURL = URL.createObjectURL(file);
      fileObjectURLs.push(fileObjectURL);
    }
    const newarray = [...file, ...selectedFiles]
    const newarray2 = [...fileURL, ...fileObjectURLs]
    console.log("ssss", newarray2)
    if (file.length < 3 && newarray.length > 3) {
      alert("You need at least 2 files or less than 4 files to merge.")
      return;
    }
    setFile(newarray);
    setFileURL(newarray2);

    setHidediv(true);
    localStorage.setItem("array", newarray2)

  };

  const navigate = useNavigate();
  const handleAudio = (id) => {
    setIsHide(id);
  };
  const mergePdf = async () => {
    if (file.length < 3 && file.length > 3) {
      alert("You need at least 2 files or less than 3 files to merge.")
      return;
    }
    try {

      var formdata = new FormData();
      { fileURL.map((number, k) => <>{formdata.append("pdf_file", file[k])}</>) }
      var requestOptions = {
        method: 'POST',
        body: formdata,
        redirect: 'follow'
      };
      const response = await fetch("http://localhost:4343/pdf_merger", requestOptions)
        .then(response => {
          if (response.ok) {
            console.log("output", response)
            const data = response.text();
            data.then(result => { localStorage.setItem("outp", JSON.stringify(result)); setoutputpdf(JSON.parse(result)); console.log("pdf", JSON.parse(result)); setHidediv(3); })
            setHidediv(3)
          }
        })
        .catch(error => console.log('error', error));


    } catch (error) {
      console.error('Error fetching PDF data URL:', error);
    }
  };
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };
  useEffect(() => {
    return scrollToTop()
  }, [])
  return (
    <div>
      <div className="banner-allpage-sec ">
        <ul className="breadcrumb">
          <li><Link to="/">Home</Link></li>
          <li>Pdf</li>
        </ul>
        <div className="banner-content-sec text-center" style={{ padding: "0px 0 50px" }}>
          <h1 className="first-head"> Merge PDF</h1>
        </div>
      </div>
      <h2 className="second-head" style={{ textAlign: "center", position: "relative", zIndex: "999", top: -135 }}>Combine multiple files into a single PDF quickly and easily
        from Online</h2>
      <br />
      {(hidediv == 0) ? (
        <section style={{ textAlign: "center", position: "relative", marginTop: -120, }}>
          <div className='page-container'>
            <div style={{ border: "#ccc 2px dotted", marginTop: -120, zIndex: 0, position: "relative", borderRadius: 10, background: "#fff", padding: 50, width: "100%", margin: "auto" }}>
              <div className='upload-btn-wrapper'>
                <input type="file" style={{ fontSize: 26, borderRadius: 10, padding: "15px 30px" }} onChange={handleFileChange} multiple />
                <button className="button orange opnoriginalResultDiv" ><svg stroke="currentColor" fill="currentColor" strokeWidth="0" viewBox="0 0 512 512" focusable="false" className="chakra-icon css-13otjrl" aria-hidden="true" height="1em" width="1em" style={{ width: 30, height: 30, position: "relative", top: 0 }} xmlns="http://www.w3.org/2000/svg"><path fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="32" d="M320 367.79h76c55 0 100-29.21 100-83.6s-53-81.47-96-83.6c-8.89-85.06-71-136.8-144-136.8-69 0-113.44 45.79-128 91.2-60 5.7-112 43.88-112 106.4s54 106.4 120 106.4h56"></path><path fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="32" d="M320 255.79l-64-64-64 64m64 192.42V207.79"></path></svg>
                  Browse computer</button>
                <p>Drag and drop a file that you want to Edit Max file size :10MB</p>
              </div>
            </div>
          </div>
        </section>
      ) : ""}
      {(hidediv == 1) ?
        <section style={{ textAlign: "center", position: "relative", marginTop: -120, }}>

          <div className='page-container'>
            <div style={{ border: "#ccc 2px dotted", marginTop: -120, zIndex: 0, textAlign: "start", position: "relative", borderRadius: 10, background: "#fff", padding: 50, width: "100%", margin: "auto" }}>
              <button type="file" onClick={() => navigate(-1)} className="button orange clickForFour" style={{ padding: "10px 15px 10px", display: "inline-flex", gap: 6 }}>
                <ArrowLeft size={20} /> Back
              </button>
              <div className='filearea d-flex justify-content-center flex-wrap mb-4'>
                <div className='fileone'>
                  {fileURL.map((number, k) => <>
                    <div key={k}>

                      <iframe src={fileURL[k]} />

                    </div>

                    <br />


                    {/* {'/n'} <iframe src={number} title="description"></iframe> */}
                  </>)}


                </div>
              </div>
              <div className='d-flex justify-content-end'>
                <div className='upload-btn-wrapper text-end d-block'>
                  <input type="file" style={{ fontSize: 26, width: "100%", zIndex: 999, borderRadius: 10, padding: "15px 30px" }} onChange={handleFileChange} multiple />
                  <button className="button green opnoriginalResultDiv addBtns" ><AiOutlineFileAdd size={20} />Add</button>
                </div>
                <button className='button orange ml-3' onClick={mergePdf}><BsFiletypePdf size={20} />Merge</button>
              </div>
            </div>
          </div>
        </section>
        : ""}
      {(hidediv == 2) ?
        <section style={{ textAlign: "center", position: "relative", marginTop: -120, }}>
          <div className='page-container'>
            <div>
              {fileURL.map((pdfDataURL, index) => (
                <iframe key={index} src={pdfDataURL} title={`PDF-${index}`} width="100%" height="200px" />
              ))}
            </div>
            <div style={{ border: "#ccc 2px dotted", marginTop: -120, zIndex: 0, position: "relative", borderRadius: 10, background: "#fff", padding: 50, width: "100%", margin: "auto" }}>
              {outputpdf && (
                <>

                  {/* <p>Selected File: {file.name}</p> */}

                </>
              )}

              {/* <div className='text-end'>
                <button className='button green'>Merge PDF</button>
              </div> */}
            </div>
          </div>
        </section>
        : ""}

      {(hidediv == 3) ? <>
        <section style={{ textAlign: "center", position: "relative", marginTop: -120, }}>
          <div className='page-container'>
            {outputpdf ? <><Pdfurl pdfData={outputpdf.dataUrl} /></> : null}
            <div className='d-flex justify-content-center btnGroups'>



            </div>
          </div>
        </section>


      </>

        : null}
    </div>
  );
};

export default FileUpload;
