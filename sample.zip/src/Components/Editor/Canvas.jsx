
import React,{useContext} from 'react'
import { AppContext } from '../../context';

function Canvas() { 
  const { fieldName } = useContext(AppContext);
  return (
    <>
      <div className="design-frame-box">
            <div className="icon-rfrsh" onClick="window.location.reload()"><img src="../assets/images/icon_refresh_reload.svg" alt=""/>
            
            </div>
            <img src={fieldName.name} alt=""  width="300px" height="300px"/> 
        </div>
    </>
  )
}

export default Canvas
