import React, { useContext} from 'react';
import { AppContext } from '../../../context.js';

function Dress() {
    
	const { setFieldName } = useContext( AppContext );

    const handleClick = (fileName) => {
        setFieldName({name:fileName.target.src});
    }

  return (
    <>
      <div className="templatesLogoRelatedComponentSec">    
    <div className="templatesLogoRelatedBox">
        <div className="tab-data-sec">
            <div className="templatesLogoRelatedPicker">
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/3_cover.png"/> 
                </span>
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/4_cover.png"/>
                </span>
            </div>
            <div className="templatesLogoRelatedPicker">
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/5_cover.png"/> 
                </span>
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/6_cover.png"/>
                </span>
            </div>
            <div className="templatesLogoRelatedPicker">
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/7_cover.png"/> 
                </span>
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/8_cover.png"/>
                </span>
            </div>
            <div className="templatesLogoRelatedPicker">
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/9_cover.png"/> 
                </span>
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/10_cover.png"/>
                </span>
            </div>
            <div className="templatesLogoRelatedPicker">
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/11_cover.png"/> 
                </span>
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/12_cover.png"/>
                </span>
            </div>
            <div className="templatesLogoRelatedPicker">
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/13_cover.png"/> 
                </span>
                <span className="templatesLogoRelatedOption">
                    <img alt='' onClick={(e)=>handleClick(e)} src="https://cutout.s3-us-west-2.amazonaws.com/site/id_photo_dress/man/14_cover.png"/>
                </span>
            </div>
        </div>
        <button title="" className="button btn_viewAll">Show more Logo Templates</button>
    </div>
</div>

    </>
  )
}

export default Dress
