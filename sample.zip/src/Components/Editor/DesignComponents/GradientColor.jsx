import React from 'react'

function GradientColor() {
  return (
    <>
      <div className="gradient-color-component-sec">    
            <div className="color-palette-box">
                <div className="heading">Colors Option</div>
                <div className="color-picker">
                    <span className="color-item" style={{backgroundColor:"#ffffff"}}></span>
                    <span className="color-item" style={{backgroundColor:"#000000"}}></span>                
                </div>
            </div>
            <div className="color-palette-box">
                <div className="heading">Gradient Style</div>
                <div className="color-picker">                
                    <span className="color-item" style={{background:"linear-gradient(to bottom,  #f0f9ff 0%, #eee 47%, #ccc 100%)"}}></span>            
                    <span className="color-item" style={{background:"linear-gradient(to top, #f0f9ff 0%, #eee 47%, #ccc 100%)"}}></span>
                    <span className="color-item" style={{background:"linear-gradient(to right, #f0f9ff 0%, #eee 47%, #ccc 100%)"}}></span>
                    <span className="color-item" style={{background:"linear-gradient(to left, #f0f9ff 0%, #eee 47%, #ccc 100%)"}}></span>
                    <span className="color-item" style={{background:"radial-gradient(ellipse at top left, #ccc 0%, #fff 100%)"}}></span>
                </div>
            </div>
        </div>

    </>
  )
}

export default GradientColor
