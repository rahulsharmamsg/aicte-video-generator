import React from "react";

function Resize() {
  return (
    <>
      <div className="iconsComponentSec">
        <div className="iconsBox">
          <div data-v-575fb2d6="" className="row idPhotolist-all no-gutters">
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters active">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Common Sizes(X)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Common Sizes(X)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Common Sizes(X)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3x4cm)(354*472px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Albania(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4x5cm)(472*590px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Argentina(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (1,5 x 1,5")(448*448px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Australia(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Austria(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Bahamas(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Bangladesh(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4x5cm)(472*590px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Belarus(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4x5cm)(472*590px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Belgium(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Belize(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Bolivia(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Brazil(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (5x7cm)(590*826px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Brazil(Visa)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Brazil(ID)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3x4cm)(354*472px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Bulgaria(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Canada(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (5x7cm)(590*826px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Canada(Visa)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Canada(Citizenship)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5x4.5cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Canada(Permanent Resident Card)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                China(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.3x4.8cm)(389*566px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                China(Visa)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Colombia(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (1.5x2")(446*590px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Colombia(Visa)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Costa Rica(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Croatia(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Croatia(Driver license)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3 x 3.5)(354*413px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Cyprus(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4x5cm)(472*590px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Czech Republic(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Denmark(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Estonia(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4x5cm)(472*590px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Estonia(Passport - under 11)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4x5cm)(472*590px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Estonia(Visa)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.6 x 4.7)(425*555px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                European Union(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Finland(Passport Visa)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.6 x 4.7)(425*555px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Finland(Passport - under 11)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.6 x 4.7)(425*555px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                France(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Germany(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Germany(Passport - under 10)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Greece(Passport Visa)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4 x 6)(472*708px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Hong Kong(Passport Visa)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4x5cm)(472*590px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Hungary(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                India(Passport 3.5x3.5 cm)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 3.5)(413*413px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                India(Passport 5x5 cm)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                India(Passport 3.5x4.5 cm)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                India(Visa)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                India(Overseas Citizenship (OCI))
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 3.5)(413*413px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                India(PAN Card)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2.5 x 3.5)(295*413px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Indonesia(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Iran(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3x4cm)(354*472px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Ireland(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Israel(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Italy(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Jamaica(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Japan(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Japan(Visa)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4.5 x 4.5)(531*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Kenya(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Korea(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Lebanon(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Malaysia(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 5)(413*590px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Malaysia(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Mexico(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Morocco(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Netherlands(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Netherlands(Passport - under 11)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                New Zealand(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Nigeria(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Norway(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Pakistan(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Panama(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Peru(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Philippines(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Poland(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Portugal(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Portugal(Citizenship)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (1,5 x 1,5")(448*448px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Romania(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Russia(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Singapore(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                South Africa(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                South Africa(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Spain(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3x4cm)(354*472px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Sweden(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Switzerland(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Switzerland(Passport - under 11)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Syria(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4x4cm)(472*472px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Taiwan(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Taiwan(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Tanzania(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Thailand(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Trinidad and Tobago(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (4.3 x 5.3)(507*625px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Trinidad and Tobago(Machine Readable Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.1 x 4.1)(366*484px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Turkey(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (5 x 6)(590*708px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Ukraine(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                United Kingdom(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                United States of America(USA)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2x2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Uzbekistan(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (3.5 x 4.5 cm)(413*531px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Venezuela(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Vietnam(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
            <div data-v-575fb2d6="" className="row idPhotolist no-gutters">
              <div data-v-575fb2d6="" className="idPhotolist-one col col-12">
                Zimbabwe(Passport)
              </div>{" "}
              <div data-v-575fb2d6="" className="idPhotolist-two col col-12">
                (2 x 2")(600*600px)
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Resize;
