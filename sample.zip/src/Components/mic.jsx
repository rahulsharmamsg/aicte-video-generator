import React, { useState, useRef } from 'react';

const Recorder = () => {
    const [isRecording, setIsRecording] = useState(false);
    const [recordedChunks, setRecordedChunks] = useState([]);
    const microphoneRef = useRef(null);
    const mediaRecorderRef = useRef(null);

    const handleStartRecording = () => {
        setIsRecording(true);
        setRecordedChunks([]);

        // Use your microphone input source
        const stream = microphoneRef.current.stream;

        mediaRecorderRef.current = new MediaRecorder(stream, { mimeType: 'audio/wav' });

        mediaRecorderRef.current.ondataavailable = (event) => {
            if (event.data.size > 0) {
                setRecordedChunks((prevChunks) => [...prevChunks, event.data]);
            }
        };

        mediaRecorderRef.current.start();
    };

    const handleStopRecording = () => {
        if (mediaRecorderRef.current) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
            const audioBlob = new Blob(recordedChunks, { type: 'audio/wav' });
            const url = URL.createObjectURL(audioBlob);

            // Do something with the recorded audio blob and URL, such as saving or playing it.
            // Example:
            // setAudioBlob(audioBlob);
            // setAudioUrl(url);
        }
    };

    return (
        <div>
            <h1>Audio Recorder</h1>
            <button onClick={isRecording ? handleStopRecording : handleStartRecording}>
                {isRecording ? 'Stop Recording' : 'Start Recording'}
            </button>
        </div>
    );
};

export default Recorder;
