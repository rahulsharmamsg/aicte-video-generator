import React from "react";
import Table from 'react-bootstrap/Table';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
  } from 'chart.js';
import { Bar } from 'react-chartjs-2';

// import CanvasJSReact from '@canvasjs/react-charts';
import landsliderimg from '../../assets/images/newspaper/NewsAggregator_Layout_Banner.jpg'
import newsGrph1 from '../../assets/images/newspaper/statsIcn.png'
import newsGrph2 from '../../assets/images/newspaper/statsIcnbl.png'
import newsGrph3 from '../../assets/images/newspaper/statsIcnrd.png'
import { CheckCircle, Newspaper, SortAscending, ThumbsDown, ThumbsUp } from "phosphor-react";
import { BiCalendarCheck } from "react-icons/bi";
// import faker from 'faker';
function NewsDashboard(){
    ChartJS.register(
        CategoryScale,
        LinearScale,
        BarElement,
        Title,
        Tooltip,
        Legend
      );
    // var CanvasJS = CanvasJSReact.CanvasJS;
    // var CanvasJSChart = CanvasJSReact.CanvasJSChart;
    
     const options = {
        plugins: {
          title: {
            display: true,
            text: '',
          },
        },
        responsive: true,
        scales: {
          x: {
            stacked: true,
          },
          y: {
            stacked: true,
          },
        },
      };




const labels = ['Jan', 'Feb', 'March', 'April', 'May', 'June', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const data = {
    labels,
    datasets: [
      {
        label: 'Positive',
        data: [146, 48, 644, 18, 911, 656, 232, 146, 48, 644, 18, 911],
        backgroundColor: 'rgb(25, 134, 255)',
       
      },
      {
        label: 'Negative',
        data: [146, 48, 644, 18, 911, 656, 232, 146, 48, 644, 18, 911],
        backgroundColor: 'rgb(255, 99, 132)',
      },
    //   {
    //     label: 'Dataset 3',
    //     data: [146, 48, 644, 18, 911, 656, 232],
    //     backgroundColor: 'rgb(53, 162, 235)',
    //   },
    ],
    
  };
  const data2 = {
    labels,
    datasets: [
      {
        label: 'Positive',
        data: [146, 48, 644, 18, 911, 656, 232, 146, 48, 644, 18, 911],
        backgroundColor: 'rgb(25, 134, 255)',
       
      },

    //   {
    //     label: 'Dataset 3',
    //     data: [146, 48, 644, 18, 911, 656, 232],
    //     backgroundColor: 'rgb(53, 162, 235)',
    //   },
    ],
  };
  const data3 = {
    labels,
    datasets: [
      {
        label: 'Negative',
        data: [146, 48, 644, 18, 911, 656, 232, 146, 48, 644, 18, 911],
        backgroundColor: 'rgb(255, 99, 132)',
      },
    //   {
    //     label: 'Dataset 3',
    //     data: [146, 48, 644, 18, 911, 656, 232],
    //     backgroundColor: 'rgb(53, 162, 235)',
    //   },
    ],
  };
return(

    <div className="landingSrch">
    <div className="landingSliderDiv"><img src={landsliderimg} alt="" />
        <div className='magicEyeTtl'> <span>Magic Eye</span></div>
    </div>
<div className="newsDashbrdCnt">
    <div className="container">
        <h2 className="newsHdng">All India Stats</h2>
        <div className="newsStatsBx">
            <div className="row">
            <div className="col-md-4 col-xs-12 statsBx1 totalNews">
                <div className="statsBx1In">
                    <h2>Total News <span>2500</span></h2>
                    <h3 className="nwsGrphIcn"><img src={newsGrph1} alt="" /></h3>
                    <span className="newsIcnCat"><Newspaper size={32} /></span>
                </div>
            </div>
            <div className="col-md-4 col-xs-12 statsBx1 postvNws">
                <div className="statsBx1In">
                    <h2>Positive News <span>2000</span></h2>
                    <h3 className="nwsGrphIcn"><img src={newsGrph2} alt="" /></h3>
                    <span className="newsIcnCat"><ThumbsUp size={32} /></span>
                </div>
            </div>
            <div className="col-md-4 col-xs-12 statsBx1 negNws">
                <div className="statsBx1In">
                    <h2>Negative News <span>500</span></h2>
                    <h3 className="nwsGrphIcn"><img src={newsGrph3} alt="" /></h3>
                    <span className="newsIcnCat"><ThumbsDown size={32} /></span>
                </div>
            </div>
            </div>
        </div>
        <div className='lstngFltr newsDshbrdFltrDiv'>
                    <form action="">
                    <div className='fltrInpt slctLang'>
                       <select name="" id="" className="form-control">
                        <option value="">Select Language</option>
                        <option value="">English</option>
                        <option value="">Hindi</option>
                       </select>
                        </div>
                        <div className='fltrInpt'>
                        <input type="radio" name='filter' /> <span>Last 7 days</span>
                        </div>
                        <div className='fltrInpt'>
                        <input type="radio" name='filter' /> <span>Last 15 days</span>
                        </div>
                        <div className='fltrInpt'>
                        <input type="radio" name='filter' /> <span>Last 30 days</span>
                        </div>
                        <div className='fltrInpt fromDate'>
                         <span>From Date</span> <input type="text" className='form-control inptClndr' /> <BiCalendarCheck size={32} className='dtIcnn' />
                        </div>
                        <div className='fltrInpt fromDate todate'>
                         <span>To Date</span> <input type="text" className='form-control inptClndr' /> <BiCalendarCheck size={32} className='dtIcnn' />
                        </div>
                        <div className='fltrInpt'>
                         <button className='srchBtnn'>Filter</button>
                        </div>
                    </form>
                </div>

                <div className="tblGrphBtm">
                    <div className="row">
                    <div className='col-md-12 lstUpdate'>
                    <span>Last Updated At: 14 Nov 2023 04:15 PM</span>
                </div>
                    <div className="col-md-7 col-xs-12 tblDiv">
                        <div className="tblDivIn">
                            <h4 className="tblSbHdng">India</h4>
                            <Table responsive="sm" className="table table-striped dashnwsTbl">
        <thead>
          <tr>
            <th>State <SortAscending size={26} /></th>
            <th>Positive News <SortAscending size={26} /></th>
            <th>Negative News <SortAscending size={26} /></th>
            <th>Total News <SortAscending size={26} /></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>ANDAMAN & NICOBAR ISLANDS</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>ANDAMAN NICOBAR</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>ANDHRA PRADESH</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>ARUNACHAL PRADESH</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>ASSAM</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>BIHAR</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>CHANDIGARH</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>CHHATTISGARH</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>DADRA & NAGAR HAVELI</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>DADRA AND NAGAR HAVELI AN</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>DAMAN & DIU</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>DELHI</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>GOA</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>GUJARAT</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>HARYANA</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>HIMACHAL PRADESH</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>JAMMU & KASHMIR</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>JAMMU KASHMIR</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>JHARKHAND</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>KARNATAKA</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>KERALA</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>LAKSHADWEEP</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>MADHYA PRADESH</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>MAHARASHTRA</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>MANIPUR</td>
            <td>55</td>
            <td>45</td>
            <td>10</td>
          </tr>
          <tr>
            <td>MEGHALAYA</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>MIZORAM</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>NAGALAND</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          <tr>
            <td>ODISHA</td>
            <td>55</td>
            <td>45</td>
            <td>100</td>
          </tr>
          
        </tbody>
      </Table>
                        </div>
                    </div>
                    <div className="col-md-5 col-xs-12 tblDiv grphDiv">
                        <div className="grphDivIn totalNws">
                        <h4 class="tblSbHdng">Total News</h4>
                        <div className="totalnwsGrph totalnewsin">
			
            <Bar options={options} data={data} />
				
		</div>
        <div className="grphDivIn postvNews">
     <h4 class="tblSbHdng">Positive News</h4>
     <div className="totalnwsGrph positivenewsin">
     <Bar options={options} data={data2} />
    </div>
    </div>
    <div className="grphDivIn negtNws">
     <h4 class="tblSbHdng">Negative News</h4>
     <div className="totalnwsGrph negativenewsin">
     <Bar options={options} data={data3} />
      </div>
    </div>
                        </div>
                    </div>
                </div>
                </div>
    </div>
</div>
    </div>

)
}
export default NewsDashboard