import React from 'react'

import Footer from '../../Components/Footer'
import { Outlet } from 'react-router-dom'
import NewsHeader from './components/newsheader'
export default function NewsOutletRoute() {
  return (
   <>
   <NewsHeader/>
   <Outlet/>
   <Footer/>
      </>
  )
}
