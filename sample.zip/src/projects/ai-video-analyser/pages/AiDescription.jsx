import React, {  useEffect, useState} from "react";

import { Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import { Progress } from "react-sweet-progress";
import "react-sweet-progress/lib/style.css";
// import ProgressBar from "react-bootstrap/ProgressBar";
import imange from "../assets/images/sucess.png";


function AiDiscription() {
  const [response, setResponse] = useState();
  const [transcript, setTranscript] = useState();
  const [confidence, setconfidence] = useState();
  const [path, setpath] = useState();

 

  useEffect(() => {
    let data = JSON.parse(localStorage.getItem("reasponse"));

    setTranscript(localStorage.getItem("transcript"));
    setResponse(data.percentage);
    setpath(data.path);
    let percent = data.percentage?.percentage;
    setconfidence(Math.floor(percent));
  }, []);

//   console.log(studentDetails,"this is student details")

  return (
    <>
      <div className="banner-allpage-sec">
        <ul className="breadcrumb">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li><Link to="/video/">Video</Link></li>
          <li><Link to="/video/">Ai video Analyser</Link></li>
          <li><Link to="/video/AiDiscription/">Detail Page</Link></li>
        </ul>
        <div className="banner-content-sec text-center">
          <h1 className="first-head">AI Video Analyser</h1>
          <h3 className="second-head">
          Analyze facial expressions in real-time from any video and gain insights into emotions with just a few clicks. Understand the feelings behind every smile, frown, and more.
          </h3>
          <br />
        </div>
      </div>
      <main className="contentarea text-start">
        <section className="selectLang mt-5">
          <div className="container">
            <div className="row">
              <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                <div className="uploadvideo">
                  <video
                    width="320"
                    height="240"
                    src={
                      path +
                      `?sp=r&st=2023-01-18T06:07:13Z&se=2028-12-31T14:07:13Z&spr=https&sv=2021-06-08&sr=c&sig=HtVlU%2BSsWizlSOrpTEIr40tfVncy74Og2N4VnG8cTH8%3D`
                    }
                    controls
                  ></video>
                </div>
              </div>
              <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                <div className="videoDetail">
                 {/* <div className="videoDetail">
                <ul>
                <li>Unique ID : {studentDetails?.stu?.student[0]?.uniqueId}</li>
                <li>Name : {studentDetails?.stu?.student[0]?.student_name}</li>
                <li>State :{studentDetails?.stu?.student[0]?.state}</li>
                <li>District :{studentDetails?.stu?.student[0]?.district}</li>
                <li>Pin Code :{studentDetails?.stu?.student[0]?.pin_code}</li>
                <li>Class : {studentDetails?.stu?.student[0]?.class}</li>
                <li>Gender : {studentDetails?.stu?.student[0]?.gender}</li>
                <li>Mobile Number :{studentDetails?.stu?.student[0]?.mobile}</li>
                <li>DOB : {studentDetails?.stu?.student[0]?.dob}</li>
                <li>School Name :{studentDetails?.stu?.student[0]?.school_name}</li>
                <li>School Board : {studentDetails?.stu?.student[0]?.school_board}</li>
                </ul>
                </div>  */}

                  <Table responsive bordered striped hover>
                    <tbody>
                      <tr>
                        <th>Your Confidene Score</th>
                        <td>{confidence ? confidence + "%" : "NA"}</td>
                      </tr>
                      <tr>
                        <th>Confidence level</th>
                        {confidence > 50 && confidence <= 60 ? (
                          <th>Avarage</th>
                        ) : confidence > 60 && confidence <= 75 ? (
                          <td>good</td>
                        ) : confidence > 75 ? (
                          <td>Very good</td>
                        ) : (
                          <td>Below average</td>
                        )}
                      </tr>
                    </tbody>
                  </Table>
                  {/* <ul>
                    <li className="d-flex justify-content-between">
                      <span>{"😁(happy)"}</span>
                      <Progress percent={Math.floor(response?.happy)} />
                    </li>
                    <li className="d-flex justify-content-between">
                      <span>😀 {"(neutral)"}</span>{" "}
                      <Progress percent={Math.floor(response?.neutral)} />{" "}
                    </li>
                    <li className="d-flex justify-content-between">
                      <span>☹️ {"(angry)"}</span>{" "}
                      <Progress percent={Math.floor(response?.angry)} />{" "}
                    </li>
                    <li className="d-flex justify-content-between">
                      <span>😔 {"(surprise)"}</span>{" "}
                      <Progress percent={Math.floor(response?.surprise)} />
                    </li>
                    <li className="d-flex justify-content-between">
                      <span>😱 {"(fear)"}</span>{" "}
                      <Progress percent={Math.floor(response?.fear)} />
                    </li>
                    <li className="d-flex justify-content-between">
                      <span>🥹 {"(sad)"}</span>{" "}
                      <Progress percent={Math.floor(response?.sad)} />
                    </li>
                    {/* <li className='d-flex justify-content-between'><span>😱 {'(happy)'}</span> <Progress percent={Math.floor(response?.fear)} /></li> 
                  </ul> */}
                  <Table>
                    <tbody>
                    <tr>
                      <th className="width-30">{"😁(happy)"}</th>
                      <td><Progress percent={Math.floor(response?.happy)} /></td>
                    </tr>
                    <tr>
                      <th className="width-30">😀 {"(neutral)"}</th>
                      <td><Progress percent={Math.floor(response?.neutral)} /></td>
                    </tr>
                    <tr>
                      <th className="width-30">☹️ {"(angry)"}</th>
                      <td><Progress percent={Math.floor(response?.angry)} /></td>
                    </tr>
                    <tr>
                      <th className="width-30">😔 {"(surprise)"}</th>
                      <td><Progress percent={Math.floor(response?.surprise)} /></td>
                    </tr>
                    <tr>
                      <th className="width-30">😱 {"(fear)"}</th>
                      <td><Progress percent={Math.floor(response?.fear)} /></td>
                    </tr>
                    <tr>
                      <th className="width-30">🥹 {"(sad)"}</th>
                      <td><Progress percent={Math.floor(response?.sad)} /></td>
                    </tr>
                    </tbody>
                  </Table>
                </div>
              </div>
            </div>

            <div className="row mt-4">
              {transcript && (
                <>
                  <div className="col-12 col-md-12 col-md-12 col-lg-12">
                    <h3>Transcript</h3>
                    <div className="videotext originalResultDiv mt-3">
                      <p>{transcript ? transcript : "no text available"}</p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </section>
        <div
          className="container"
          style={{
            textAlign: "center",
           
            position: "relative",
            marginBottom: 50,
          }}
        >
          <div
            class="stepFour clickForFive"
            style={{
              borderRadius: 10,
              background: "rgb(190, 227, 248)",
              padding: 50,
              width: "100%",
              marginTop: "1rem",
            }}
          >
            <p class="chakra-text">
              <img src={imange} alt="" style={{ width: 65 }} />
              {/* <div className="loader"></div> */}
            </p>
            <div
              class="chakra-heading"
              style={{ fontSize: 20, fontWeight: "bold" }}
            >
              Your video has been successfully processed...
            </div>
            {/* <p class="chakra-text">This may take some time. Stay on this page or come back later to get the result.</p> */}
          </div>
        </div>
      </main>
    </>
  );
}

export default AiDiscription;
