import React from "react";
import { Route, Routes } from "react-router-dom";
import AiVideoAnalyser from "./pages/AiVideoFaceSummary";
import AiDiscription from "./pages/AiDescription";
import LanguageSelect from "./pages/LanguageSelect";


const VideoRouter = () => {
    return (
        <Routes>
            <Route index element={<LanguageSelect />} />
            <Route path="/" element={<LanguageSelect />} />
            <Route path="/AivideoAnalyser" element={<AiVideoAnalyser />} />
            <Route path="/AiDiscription" element={<AiDiscription />} />
 
        </Routes>
    )
}

export default VideoRouter