import React,{useState} from 'react'
import { Container, Form, Button} from 'react-bootstrap'
import { BiLogOutCircle } from "react-icons/bi";
import CustomView from './Components/CustomView';

function SignupMessenger() {
    const [formData, setFormData] = useState({
        firstName: '',
        email: '',
        number: '',
        password: ''
      });
      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
          ...formData,
          [name]: value
        });
      };
      const handleSubmit = (e) => {
        e.preventDefault();
        console.log( formData);
      };
  return (
    <>
    <main className='contentarea'>
        <section className=''>
            <Container>
                <div className='signup'>
                    <div className='profileView'>
                    <CustomView/>
                    </div>
                <Form onSubmit={handleSubmit}>
                <Form.Group className="text-start">
                  <Form.Label htmlFor="firstName">User Name</Form.Label>
                  <Form.Control type="number" name='firstName' autocomplete="off"
                  value={formData.firstName}
                  onChange={handleInputChange}/>
                </Form.Group>
                <Form.Group className="text-start mt-3">
                  <Form.Label htmlFor="email">Email</Form.Label>
                  <Form.Control type="email" 
                  name='email'
                  autocomplete="off" 
                  value={formData.email}
                  onChange={handleInputChange}
                  />
                </Form.Group>    
                <Form.Group className="text-start mt-3">
                  <Form.Label htmlFor="number">Phone Number</Form.Label>
                  <Form.Control type="number" autocomplete="off"
                  name='number' 
                   value={formData.phone}
                   onChange={handleInputChange}
                  />
                </Form.Group>   
                <Form.Group className="text-start mt-3">
                  <Form.Label htmlFor="password">Password</Form.Label>
                  <Form.Control type="password" autocomplete="off"
                  name='password'
                   value={formData.password}
                   onChange={handleInputChange}
                    />
                </Form.Group>          
                <Form.Group className='mt-3'>
                  <Button className="logbtn button orange">
                    <BiLogOutCircle size={20} />
                    Signup
                  </Button>
                </Form.Group>
              </Form>
                </div>
            </Container>
        </section>
    </main>
    </>
  )
}

export default SignupMessenger