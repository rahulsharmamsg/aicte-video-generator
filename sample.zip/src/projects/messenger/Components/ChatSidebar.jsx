import React,{useState, useRef} from 'react'
import {  Link } from 'react-router-dom'
import { AiOutlinePlus ,AiOutlineUser,} from "react-icons/ai";
import {LiaUsersSolid} from "react-icons/lia";
import {Tab, Tabs, Button,Form} from 'react-bootstrap';
import Scanner from './Scanner';

function ChatSidebar() {
    const [key, setKey] = useState('home');
  return (
    <>
      <div className='chatside'>
      <Tabs
      id="controlled-tab-example"
      activeKey={key}
      onSelect={(k) => setKey(k)}
      className="mb-3"
    >
        <Tab eventKey="home" title="+">
            <div className='qrcodeDiv'>
              {/* <Scanner/> */}
                <p>SHOW QR-CODE to join a chat (or) Open Scanner To create a chat</p>
                <Form className='d-flex justify-content-start'>
                  <Form.Group>
                    <Form.Control type="text" placeholder="ID" />
                  </Form.Group>
                  <Form.Group className='ml-2'>
                    <Form.Control type="text" placeholder="Chat Name" />
                  </Form.Group>
                  <Button className='addBtn'><AiOutlinePlus size={20} /></Button>
                </Form>
            </div>
        </Tab>
        <Tab eventKey="profile" title="Recent">
            <ul className='recentdiv'>
                <li><Link><span><AiOutlineUser size={20}/></span> Recent1</Link></li>
                <li><Link><span><AiOutlineUser size={20}/></span> Recent1</Link></li>
                <li><Link><span><AiOutlineUser size={20}/></span> Recent1</Link></li>
                <li><Link><span><AiOutlineUser size={20}/></span> Recent1</Link></li>
                <li><Link><span><AiOutlineUser size={20}/></span> Recent1</Link></li>
               
            </ul>
        </Tab>
        <Tab eventKey="grpChat" title="Group Chat">
            <ul className='recentdiv users'>
                <li><Link><span><LiaUsersSolid size={23}/></span> Group Chat</Link></li>
                <li><Link><span><LiaUsersSolid size={23}/></span> Group Chat</Link></li>
                <li><Link><span><LiaUsersSolid size={23}/></span> Group Chat</Link></li>
                <li><Link><span><LiaUsersSolid size={23}/></span> Group Chat</Link></li>
            </ul>
        </Tab>
        </Tabs>
        
      </div>
    </>
  )
}

export default ChatSidebar
