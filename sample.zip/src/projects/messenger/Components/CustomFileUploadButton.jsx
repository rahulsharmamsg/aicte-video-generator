// CustomFileUploadButton.js

import React from 'react';
import styled from 'styled-components';
import { AiOutlineFileImage } from "react-icons/ai";
const Input = styled.input`
  display: none;
`;

const Button = styled.label`
  display: inline-block;
  padding: 10px 20px;
  background-color: #3498db;
  color: #fff;
  border: none;
  cursor: pointer;
`;

const CustomFileUploadButton = ({ onChange }) => {
  return (
    <>
      <Input type="file" id='file' onChange={onChange} />
      <Button htmlFor="file" className='button green'><AiOutlineFileImage size={20}/>Upload a File</Button>
    </>
  );
};

export default CustomFileUploadButton;
