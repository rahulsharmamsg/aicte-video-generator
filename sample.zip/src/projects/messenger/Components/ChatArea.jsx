import React from 'react'
import { AiOutlineUser} from "react-icons/ai";


function ChatArea() {
  return (
    <>
   
      <section className='chat'>
      <div class="message-divider sticky-top pb-2" data-label="Yesterday">Yesterday</div>
            <div class="message">
                <div class="message-wrapper">
                    <div class="message-content">
                        <span>I have done a lot of research on the subject, and I know I can
                            answer any questions I will receive from the audience.</span>
                    </div>
                </div>
                <div class="message-options">
                    <div class="avatar avatar-sm"><AiOutlineUser color='#52df84' size={20}/></div>
                    <span class="message-date">9:12am</span>                    
                </div>
            </div>
            <div class="message self">
                <div class="message-wrapper">
                    <div class="message-content">
                        <span>I have done a lot of research on the subject, and I know I can
                            answer any questions I will receive from the audience.</span>
                    </div>
                </div>
                <div class="message-options">
                    <div class="avatar avatar-sm"><AiOutlineUser color='#52df84' size={20}/></div>
                    <span class="message-date">9:12am</span>                    
                </div>
            </div>
            <div class="message self">
                <div class="message-wrapper">
                    <div class="message-content">
                        <span>I have done a lot of research on the subject, and I know I can
                            answer any questions I will receive from the audience.</span>
                    </div>
                </div>
                <div class="message-options">
                    <div class="avatar avatar-sm"><AiOutlineUser color='#52df84' size={20}/></div>
                    <span class="message-date">9:12am</span>                    
                </div>
            </div>
            <div class="message">
                <div class="message-wrapper">
                    <div class="message-content">
                        <span>I have done a lot of research on the subject, and I know I can
                            answer any questions I will receive from the audience.</span>
                    </div>
                </div>
                <div class="message-options">
                    <div class="avatar avatar-sm"><AiOutlineUser color='#52df84' size={20}/></div>
                    <span class="message-date">9:12am</span>                    
                </div>
            </div>
            <div class="message self">
                <div class="message-wrapper">
                    <div class="message-content">
                        <span>I have done a lot of research on the subject, and I know I can
                            answer any questions I will receive from the audience.</span>
                    </div>
                </div>
                <div class="message-options">
                    <div class="avatar avatar-sm"><AiOutlineUser color='#52df84' size={20}/></div>
                    <span class="message-date">9:12am</span>                    
                </div>
            </div>
    
      </section>
    </>
  )
}

export default ChatArea