import React from "react";
import { Image } from "react-bootstrap";
import blog from "../assets/images/blog-img-1.jpg";
import blog2 from "../assets/images/blog-img-2.jpg";
import blog3 from "../assets/images/blog-img-3.jpg";
import benefit1 from "../assets/images/benefit_1.png";
import benefit2 from "../assets/images/benefit_2.png";
import benefit3 from "../assets/images/benefit_3.png";
import ic from "../assets/images/ic_social.svg";
import ic2 from "../assets/images/ic_folder.svg";
import ic3 from "../assets/images/ic_shirt.svg";
import ic4 from "../assets/images/ic_pen_tool.svg";
import ic5 from "../assets/images/ic_social.svg";
import ic6 from "../assets/images/ic_file.svg";
import CommonBanner from "../Components/CommonBanner";

function DetailPage() {
  return (
    <>
      <CommonBanner
        title="ANUVADINI's"
        ttitle="Passport Photo Maker"
        stitle="Fast, simple and easy to use tool you'll love."
        para="or drop a file here CTRL+V to paste image or URL"
      />
      <div className="page-container logo-maker-page">
        <section>
          <h2 className="text-center">SMARTER. FASTER. EASIER.</h2>
          <br />
          <div className="row text-center sfe-sec">
            <div className="col-lg-4">
              <div className="box">
                <Image src={benefit1} alt="SMARTER" />
                <h3>Smarter</h3>
                <strong>Uses proprietary AI technology</strong>
                <p>
                  Designsthan uses machine learning to simplify your creative
                  workflow. Less Manual work, more time to focus on the bigger
                  picture.
                </p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="box">
                <Image src={benefit2} alt="SMARTER" />
                <h3>Faster</h3>
                <strong>Exceptional results in less than 2 minutes</strong>
                <p>
                  Create full marketing campaigns in only 2 minutes with
                  artificial intellugence. Quicker creation time, more clients
                  and revenue.
                </p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="box">
                <Image src={benefit3} alt="SMARTER" />
                <h3>Easier</h3>
                <strong>Intuitive and accessible to all</strong>
                <p>
                  With its intuitive user experience, Designsthan make design
                  accessible. You can create stunning visual content even as a
                  beginner.
                </p>
              </div>
            </div>
          </div>
        </section>
      </div>
      <div className="features-homepage-sec">
        <div className="page-container logo-maker-page">
          <h2 className="text-center">Why Choose ANUVADINI AI Tool</h2>
          <br />
          <div className="row text-center why-choose-sec">
            <div className="col-lg-4">
              <div className="box">
                <Image
                  src={ic}
                  alt=""
                  loading="lazy"
                  height="100"
                  width="100"
                />
                <h3>High Resolution Image</h3>
                <p>
                  Download your Image in high resolution for digital use or
                  printing.
                </p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="box">
                <Image
                  src={ic2}
                  alt=""
                  loading="lazy"
                  height="100"
                  width="100"
                />
                <h3>Image files</h3>
                <p>
                  SVG, PNG, EPS & PDF image files that let you scale your photo
                  to any size.
                </p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="box">
                <Image
                  src={ic3}
                  alt=""
                  loading="lazy"
                  height="100"
                  width="100"
                />
                <h3>Color variations</h3>
                <p>
                  Get black and white, colored, and transparent background
                  variations of your photo, video, logo.
                </p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="box">
                <Image
                  src={ic4}
                  alt=""
                  loading="lazy"
                  height="100"
                  width="100"
                />
                <h3>Print-Ready Files</h3>
                <p>
                  Print your photo anywhere from business cards to billboards.
                </p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="box">
                <Image
                  src={ic5}
                  alt=""
                  loading="lazy"
                  height="100"
                  width="100"
                />
                <h3>Social Media Kit</h3>
                <p>
                  Use your photo, video, logo on all your social media channels
                  eg. Facebook, Twitter, YouTube, and more.
                </p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="box">
                <Image
                  src={ic6}
                  alt=""
                  loading="lazy"
                  height="100"
                  width="100"
                />
                <h3>Brand Guide</h3>
                <p>
                  Brand consistency is key. Get all the details about your
                  photo, video, logo.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="page-container" style={{ maxWidth: 900 }}>
        <section>
          <h2 className="text-center">The useful photo edit questions</h2>
          <h4 className="accordion">How to make passport photo?</h4>
          <div className="panel">
            <p>
              Take the perfect photo at home using your smartphone or choose the
              best photo from your cellphone album. With Single-Click to upload
              your photo onto cutout.pro, in One Second, your photo is ready. No
              need to download and install passport photo app or professional
              photo software such as photoshop. No need to manually
              resize/crop/adjust picture size or margin like traditional online
              digital passport/visa photo editors.
            </p>
          </div>
          <h4 className="accordion">How to change passport suit?</h4>
          <div className="panel">
            <p>
              You don’t need to wear formal suit, we provide suit changer with a
              collection of HD quality women/men/girls/boys formal smart suits
              for passport or ID designs and style. Selecting your favorite
              outfit, you can experiment and test out all the suits. Make them
              as attractive as you could.
            </p>
          </div>
          <h4 className="accordion">How to print passport photo?</h4>
          <div className="panel">
            <p>
              Download passport photo PNG or JPG/JPEG file, then order prints
              from print service providers. Or, you can take your phone to local
              near photo print service providers and get it printed.
            </p>
          </div>
        </section>
      </div>
      <div className="page-container">
        <div className="main-container">
          <section className="blog-homepage-sec">
            <div className="blog-content-sec">
              <h2 className="text-center">Read more logo design article</h2>
              <div className="row">
                <div className="blog-card col-lg-4">
                  <div className="blog-card-img">
                    <Image src={blog} alt="" />
                  </div>
                  <div className="blog-card-content">
                    <span className="blog-cat-name">Creativity</span>
                    <h3 className="blog-head-name">
                      How to Design a Logo For Your Business?
                    </h3>
                  </div>
                </div>
                <div className="blog-card col-lg-4">
                  <div className="blog-card-img">
                    <Image src={blog2} alt="" />
                  </div>
                  <div className="blog-card-content">
                    <span className="blog-cat-name">Branding</span>
                    <h3 className="blog-head-name">
                      Which is the best color to create Logo? Here’s How to
                      Check
                    </h3>
                  </div>
                </div>
                <div className="blog-card col-lg-4">
                  <div className="blog-card-img">
                    <Image src={blog3} alt="" />
                  </div>
                  <div className="blog-card-content">
                    <span className="blog-cat-name">Design</span>
                    <h3 className="blog-head-name">
                      The latest 2022 Logo Design Trends Which You Will Up Your
                      Brand
                    </h3>
                  </div>
                </div>
                <div className="blog-card col-lg-4">
                  <div className="blog-card-img">
                    <Image src={blog2} alt="" />
                  </div>
                  <div className="blog-card-content">
                    <span className="blog-cat-name">Branding</span>
                    <h3 className="blog-head-name">
                      How to Create a Business Logo According to Your Industry?
                    </h3>
                  </div>
                </div>
                <div className="blog-card col-lg-4">
                  <div className="blog-card-img">
                    <Image src={blog3} alt="" />
                  </div>
                  <div className="blog-card-content">
                    <span className="blog-cat-name">Design</span>
                    <h3 className="blog-head-name">
                      How to Use Designsthan Logo Maker Editor to Customize Your
                      Logo?
                    </h3>
                  </div>
                </div>
                <div className="blog-card col-lg-4">
                  <div className="blog-card-img">
                    <Image src={blog} alt="" />
                  </div>
                  <div className="blog-card-content">
                    <span className="blog-cat-name">Creativity</span>
                    <h3 className="blog-head-name">
                      Starting Step When Designing a Logo
                    </h3>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </>
  );
}

export default DetailPage;
