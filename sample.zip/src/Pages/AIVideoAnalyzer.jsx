import React from "react";
import { Link,useNavigate } from "react-router-dom";
import {Indianlanguages} from '../assets/Json/laanlist'
function AIVideoAnalyzer() {
  let navigate = useNavigate();
  const selectlang = (value) => {
    localStorage.setItem('lang', value);
    navigate("/UploadFile");
  }
  return (
    <>
    <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Video</li>
            <li>Branding</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">AI Video Analyzer</h1>
            <h3 className="second-head">Fast, simple and easy to use tool you'll love.</h3>
            <br/>            
            
        </div>
    </div>
      <main className="contentarea">
        <section className="selectlang">
          <div className="container">
            <div class="card-body">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-12 mx-auto text-center">
                  <ul class="mb-0 languageList d-flex justify-content-center">
                    {Indianlanguages.map(language =>(  <li onClick={()=>selectlang(language.value)}>{language.name}</li>))}
             
                  </ul>
                  <button class="mt-4 button green">Proceed</button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}

export default AIVideoAnalyzer;
