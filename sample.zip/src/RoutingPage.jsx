import React from 'react'
import { BrowserRouter as Router,Routes, Route,} from 'react-router-dom';
import HomePage from './Pages/HomePage';
import DetailPage from './Pages/DetailPage';
import AboutUs from './Pages/AboutUs';
import VoiceBasedMultilingualForm from './Components/VoiceBasedMultilingualForm';
import VoiceTextToTextImageToTextTranslation from './Components/VoiceTextToTextImageToTextTranslation';
import VoiceToTextAndSpeechToSpeech from './Components/VoiceToTextAndSpeechToSpeech';
import AiSummary from './Components/AiSummary';
import AiVideoGenerator from './Components/AiVideoGenerator';
import Branding from './Components/Branding';
import DictationTool from './Components/DictationTool';
import FaceCutout from './Components/FaceCutout';
import GovtofIndiaSchemesAndInitiatives from './Components/GovtofIndiaSchemesAndInitiatives';
import ImageBackgroundRemover from './Components/ImageBackgroundRemover';
import LegalGlossary from './Components/LegalGlossary';
import MannKiBat from './Components/MannKiBat';
import MeetingCapture from './Components/MeetingCapture';
import OnlineDocumentTranslationTool from './Components/OnlineDocumentTranslationTool';
import VideoTranslation from './Components/VideoTranslation';
import PassportPhotoMaker from './Components/PassportPhotoMaker';
import RemoveUnwantedObjects from './Components/RemoveUnwantedObjects';
import VideoBackgroundRemover from './Components/VideoBackgroundRemover';
import VideowithVoice from './Components/VideowithVoice';
import TexttoVideo from './Components/TexttoVideo';
import VirtualKeyboard from './Components/VirtualKeyboard';
import ScreenRecording from './Components/ScreenRecording';
import VideoRecording from './Components/VideoRecording';
import MultiCameraRecording from './Components/MultiCameraRecording';
import PhoneasWebcam from './Components/PhoneasWebcam';
import Teleprompter from './Components/Teleprompter';
import RemoveCameraBackground from './Components/RemoveCameraBackground';
import ThreeDAudio from './Components/ThreeDAudio';
import AutoPartner from './Components/AutoPartner';
import BassBooster from './Components/BassBooster';
import Equalizer from './Components/Equalizer';
import NoiseReducer from './Components/NoiseReducer';
import PitchShifter from './Components/PitchShifter';
import Reverb from './Components/Reverb';
import ReverseAudio from './Components/ReverseAudio';
import StereoPanner from './Components/StereoPanner';
import TempoChanger from './Components/TempoChanger';
import TrimmerCutter from './Components/TrimmerCutter';
import VocalRemover from './Components/VocalRemover';
import VolumeChanger from './Components/VolumeChanger';
import ImageEditor from './Components/Editor/ImageEditor';
import TirmOfUse from './Components/TirmOfUse';
import PrivacyPolicy from './Components/PrivacyPolicy';
import OutletRoute from './Components/OutletRoute';
import AIVideoAnalyzer from './Pages/AIVideoAnalyzer';
import UploadFile from './Components/UploadFile';
import AiDiscription from './Components/VideoCamera/AiDiscription';
import VideoForm from './Pages/VideoForm';
import VideoDetailPage from './Components/VideoCamera/VideoDetailPage';
// import CoreEnggRouter from './projects/core-engg/CoreEnggRoutes';
import VideoRouter from './projects/ai-video-analyser/videoRoutes'
import LoginMessenger from './projects/messenger/LoginMessenger';
import SignupMessenger from './projects/messenger/SignupMessenger';
import ChatPage from './projects/messenger/ChatPage';
import Pdfeditor from './Components/PDF/Pdfeditor';
import SplitPDF from './Components/PDF/SplitPDF';

import CookiesPolicy from './Pages/CookiesPolicy'
import NewsRouter from './projects/news/newsRouter';
import NewsOutletRoute from './projects/news/NewsOutletRoute';
import NewsLanding from './projects/news/news-landing';
import NewsDashboard from './projects/news/news-dashboard';
import NewsDashboardpie from './projects/news/news-dashboardpie';
function RoutingPage() {

  return (
    <>
    <Router>      
      {/* <Header/> */}
        <Routes>
            {/* Pages */}
            <Route path='/' element={<OutletRoute/>}>
            <Route index element={<HomePage/>}/>
            <Route path='/detailPage' element={<DetailPage/>}></Route>
            <Route path='/aboutUs' element={<AboutUs/>}></Route>
            <Route path='/cookies-policy' element={<CookiesPolicy/>}></Route>
            <Route path='/video/form' element={<VideoForm/>}></Route>
            {/* Translation */}
            <Route path='/onlineDocumentTranslationTool' element={<OnlineDocumentTranslationTool/>}></Route>
            <Route path='/govtofIndiaSchemesAndInitiatives' element={<GovtofIndiaSchemesAndInitiatives/>}></Route>
            <Route path='/mannKiBat' element={<MannKiBat/>}></Route>
            <Route path='/voiceBasedMultilingualForm' element={<VoiceBasedMultilingualForm/>}></Route>
            <Route path='/dictationTool' element={<DictationTool/>}></Route>  
            <Route path='/legalGlossary' element={<LegalGlossary/>}></Route> 
            <Route path='/videoTranslation' element={<VideoTranslation/>}></Route>
            {/* Voice */}
            <Route path='/VoiceToTextAndSpeechToSpeech' element={<VoiceToTextAndSpeechToSpeech/>}></Route>
            <Route path='/VoiceTextToTextImageToTextTranslation' element={<VoiceTextToTextImageToTextTranslation/>}></Route>
            <Route path='/ThreeDAudio' element={<ThreeDAudio/>}></Route>
            <Route path='/Autopartner' element={<AutoPartner/>}></Route>
            <Route path='/BassBooster' element={<BassBooster/>}></Route>
            <Route path='/Equalizer' element={<Equalizer/>}></Route>
            <Route path='/NoiseReducer' element={<NoiseReducer/>}></Route>  
            <Route path='/PitchShifter' element={<PitchShifter/>}></Route>  
            <Route path='/Reverb' element={<Reverb/>}></Route>  
            <Route path='/reverseAudio' element={<ReverseAudio/>}></Route>  
            <Route path='/stereoPanner' element={<StereoPanner/>}></Route>  
            <Route path='/tempoChanger' element={<TempoChanger/>}></Route>  
            <Route path='/trimmerCutter' element={<TrimmerCutter/>}></Route>  
            <Route path='/vocalRemover' element={<VocalRemover/>}></Route>  
            <Route path='/volumeChanger' element={<VolumeChanger/>}></Route>  
           {/* Video */}
           <Route path='/videoBackgroundRemover' element={<VideoBackgroundRemover/>}></Route>
           <Route path='/videowithVoice' element={<VideowithVoice/>}></Route>
           <Route path='/texttoVideo' element={<TexttoVideo/>}></Route>
           <Route path='/aiSummary' element={<AiSummary/>}></Route>
           <Route path='/aiVideoGenerator' element={<AiVideoGenerator/>}></Route>
           <Route path='/branding' element={<Branding/>}></Route>
           <Route path='/AIVideoAnalyzer' element={<AIVideoAnalyzer/>}></Route>
           <Route path='/UploadFile' element={<UploadFile/>}></Route>
           <Route path='/AiDiscription' element={<AiDiscription/>}></Route>
           <Route path='/VideoDetailPage' element={<VideoDetailPage/>}></Route>
         
           {/* Images */}
           <Route path='/passportPhotoMaker' element={<PassportPhotoMaker/>}></Route>
           <Route path='/faceCutout' element={<FaceCutout/>}></Route>
           <Route path='/removeUnwantedObjects' element={<RemoveUnwantedObjects/>}></Route>
           <Route path='/imageBackgroundRemover' element={<ImageBackgroundRemover/>}></Route>
           {/* PDF */}
           <Route path='/pdf/' element={<HomePage/>}></Route>
           <Route path='/pdf/pdfeditor' element={<Pdfeditor/>}></Route>
           <Route path='/pdf/splitPDF' element={<SplitPDF/>}></Route>
          {/* Meeting*/}
            <Route path='/virtualKeyboard' element={<VirtualKeyboard/>}></Route>
            <Route path='/screenRecording' element={<ScreenRecording/>}></Route>
            <Route path='/videoRecording' element={<VideoRecording/>}></Route>
            <Route path='/meetingCapture' element={<MeetingCapture/>}></Route>
            <Route path='/multiCameraRecording' element={<MultiCameraRecording/>}></Route>
            <Route path='/phoneasWebcam' element={<PhoneasWebcam/>}></Route>
            <Route path='/teleprompter' element={<Teleprompter/>}></Route>
            <Route path='/removeCameraBackground' element={<RemoveCameraBackground/>}></Route>
            <Route path='/tirmOfUse' element={<TirmOfUse/>}></Route>
            <Route path='/privacyPolicy' element={<PrivacyPolicy/>}></Route>
          {/* Core-Engg Routes*/}
            {/* <Route path='/core-engg/*' element={<CoreEnggRouter/>}></Route> */}
            <Route path='/video/*' element={<VideoRouter/>}></Route>
            
            <Route path='/messenger/*' element={<LoginMessenger/>}></Route>
            <Route path='/messenger/SignupMessenger' element={<SignupMessenger/>}></Route>
            <Route path='/messenger/ChatPage' element={<ChatPage/>}></Route>

            
            </Route>
            <Route path='/news' element={<NewsOutletRoute/>}>
            <Route index element={<NewsLanding/>}/>
            <Route path="/news/newsdashboard" element={<NewsDashboard/>}/>
            <Route path="/news/newsdashboardpie" element={<NewsDashboardpie/>}/>
            
              </Route>
        </Routes>
        
      {/* <Footer/> */}
      <Routes>
        <Route path='/Editor/ImageEditor' element={<ImageEditor/>}></Route>
      </Routes>
    </Router>
    </>
  )
}

export default RoutingPage
