import React from "react";
import { Route, Routes } from "react-router-dom";
import NewsLanding from "./news-landing";
import NewsDashboard from "./news-dashboard";




const NewsRouter = () => {
    return (
        <Routes>
            <Route index element={<NewsLanding />} >
            <Route path="/newsdashboard" element={<NewsDashboard />} />
</Route>
 
        </Routes>
    )
}

export default NewsRouter