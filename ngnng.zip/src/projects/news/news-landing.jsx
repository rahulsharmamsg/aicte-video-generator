import React from 'react'
import "../../assets/css/newsCss.css";
import news01 from '../../assets/images/newspaper/news01.jpg'
import news02 from '../../assets/images/newspaper/news02.jpg'
import magicEye from '../../assets/images/newspaper/magicEye.gif'
import landsliderimg from '../../assets/images/newspaper/NewsAggregator_Layout_Banner.jpg'
import { ArrowLeft, ArrowRight, CalendarCheck, Clock, Microphone } from 'phosphor-react';
import { BiCalendarCheck } from 'react-icons/bi';
function NewsLanding() {
  return (

    <div className="landingSrch">
        <div className='landingSliderDiv'><img src={landsliderimg} alt="" />
        <div className='magicEyeTtl'> <span>Magic Eye</span></div>
    </div>
       <div className='container'>
            <div className='newsSrchSec'>
        <form action="">
            <div className='topSrchDiv'>
                <div className='row'>
                <div className='form-group col-md-7 col-xs-12 wrtKeywrds'>
                    <input type="text" className='form-control' placeholder='Write Keywords Here ...' />
                    <span className='voiceCl'><Microphone size={22} /></span>
                </div>
                <div className='form-group col-md-4 col-xs-12'>
                    <select name="" id="" className='form-control'>
                        <option value="">Select Language</option>
                        <option value="">All</option>
                        <option value="">English</option>
                        <option value="">Hindi</option>
                        <option value="">Telgu</option>
                        <option value="">Tamil</option>
                    </select>
                </div>
                <div className='form-group col-md-1 col-xs-12'>
                    <button className='button green btn-login-signup'>Search</button>
                </div>
                </div>
            </div>
        </form>
        </div>
        <div className='listNewsSec'>
            <div className='row'>
                {/* <div className='col-md-12 hdrPag'>
                    <ul>
                        <li><a href="" className='prvtBtn'><ArrowLeft size={17} /></a></li>
                        <li><a href="" className='pagactive'>1</a></li>
                        <li><a href="">2</a></li>
                        <li><a href="">3</a></li>
                        <li><a href="">4</a></li>
                        <li><a href="">5</a></li>
                        <li><a href="">6</a></li>
                        <li><a href="" className='nextBtn'><ArrowRight size={17} /></a></li>
                    </ul>
                </div> */}
                <div className='lstngFltr'>
                    <form action="">
                        <div className='fltrInpt'>
                        <input type="radio" name='filter' /> <span>Last 7 days</span>
                        </div>
                        <div className='fltrInpt'>
                        <input type="radio" name='filter' /> <span>Last 15 days</span>
                        </div>
                        <div className='fltrInpt'>
                        <input type="radio" name='filter' /> <span>Last 30 days</span>
                        </div>
                        <div className='fltrInpt fromDate'>
                         <span>From Date</span> <input type="text" className='form-control inptClndr' /> <BiCalendarCheck size={32} className='dtIcnn' />
                        </div>
                        <div className='fltrInpt fromDate todate'>
                         <span>To Date</span> <input type="text" className='form-control inptClndr' /> <BiCalendarCheck size={32} className='dtIcnn' />
                        </div>
                        <div className='fltrInpt'>
                         <button className='srchBtnn'>Filter</button>
                        </div>
                    </form>
                </div>
                <div className='col-md-12 lstUpdate'>
                    <span>Last Updated At: 14 Nov 2023 04:15 PM</span>
                </div>
            <div className="col-md-4 col-xs-12 catListingDiv">
              <div className="catListingDivIn">
              <a href="javascript:void(0)">
                <div className='paperSource'>
                    <div className='paperSourceName'><strong>Source: </strong>Times of India</div>
                    <div className='paperLang'><span>English</span></div>
                </div>
                <div className="catListImg"><img src={news01} alt="" /></div>
                <div className="catListCnt">
                    <div className='posNegLine'>
                        <div className='positiveRtng'><span>Positive: <b>90%</b></span></div>
                        <div className='negtvRtng'><span>Negative: <b>10%</b></span></div>
                    </div>
                <div className="dateTmDiv">
                <div className="dIn"><CalendarCheck size={18} /> Date: <span>02 Nov 2020</span></div>
                <div className="tIn"><Clock size={18} /> Time: <span> 04:00 PM</span></div>
                </div>
                 <h2>PM Modi: The Architect Of New India</h2>
                 <p>Under his leadership, the country is realizing the dream of 'One India Great India', says CM Yogi Adityanath</p>
                 <div className="lstHsTg">
                   <ul>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                   </ul>
                 </div>
                </div>
            
              </a>
              </div>
            </div>

            <div className="col-md-4 col-xs-12 catListingDiv">
              <div className="catListingDivIn">
              <a href="javascript:void(0)">
                <div className='paperSource'>
                    <div className='paperSourceName'><strong>Source: </strong>NBT</div>
                    <div className='paperLang'><span>Hindi</span></div>
                </div>
                <div className="catListImg"><img src={news02} alt="" /></div>
                <div className="catListCnt">
                    <div className='posNegLine'>
                        <div className='positiveRtng'><span>Positive: <b>90%</b></span></div>
                        <div className='negtvRtng'><span>Negative: <b>10%</b></span></div>
                    </div>
                <div className="dateTmDiv">
                <div className="dIn"><CalendarCheck size={18} /> Date: <span>02 Nov 2020</span></div>
                <div className="tIn"><Clock size={18} /> Time: <span> 04:00 PM</span></div>
                </div>
                 <h2>प्रधानमन्त्री नरेन्द्र मोदी : अजय मोदी</h2>
                 <p>वे भारत के प्रधानमन्त्री पद पर आसीन होने वाले स्वतन्त्र भारत में जन्मे प्रथम व्यक्ति हैं।</p>
                 <div className="lstHsTg">
                   <ul>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                   </ul>
                 </div>
                </div>
            
              </a>
              </div>
            </div>

            <div className="col-md-4 col-xs-12 catListingDiv">
              <div className="catListingDivIn">
              <a href="javascript:void(0)">
                <div className='paperSource'>
                    <div className='paperSourceName'><strong>Source: </strong>Times of India</div>
                    <div className='paperLang'><span>English</span></div>
                </div>
                <div className="catListImg"><img src={news01} alt="" /></div>
                <div className="catListCnt">
                    <div className='posNegLine'>
                        <div className='positiveRtng'><span>Positive: <b>90%</b></span></div>
                        <div className='negtvRtng'><span>Negative: <b>10%</b></span></div>
                    </div>
                <div className="dateTmDiv">
                <div className="dIn"><CalendarCheck size={18} /> Date: <span>02 Nov 2020</span></div>
                <div className="tIn"><Clock size={18} /> Time: <span> 04:00 PM</span></div>
                </div>
                 <h2>PM Modi: The Architect Of New India</h2>
                 <p>Under his leadership, the country is realizing the dream of 'One India Great India', says CM Yogi Adityanath</p>
                 <div className="lstHsTg">
                   <ul>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                   </ul>
                 </div>
                </div>
            
              </a>
              </div>
            </div>

            <div className="col-md-4 col-xs-12 catListingDiv">
              <div className="catListingDivIn">
              <a href="javascript:void(0)">
                <div className='paperSource'>
                    <div className='paperSourceName'><strong>Source: </strong>Times of India</div>
                    <div className='paperLang'><span>English</span></div>
                </div>
                <div className="catListImg"><img src={news01} alt="" /></div>
                <div className="catListCnt">
                    <div className='posNegLine'>
                        <div className='positiveRtng'><span>Positive: <b>90%</b></span></div>
                        <div className='negtvRtng'><span>Negative: <b>10%</b></span></div>
                    </div>
                <div className="dateTmDiv">
                <div className="dIn"><CalendarCheck size={18} /> Date: <span>02 Nov 2020</span></div>
                <div className="tIn"><Clock size={18} /> Time: <span> 04:00 PM</span></div>
                </div>
                 <h2>PM Modi: The Architect Of New India</h2>
                 <p>Under his leadership, the country is realizing the dream of 'One India Great India', says CM Yogi Adityanath</p>
                 <div className="lstHsTg">
                   <ul>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                   </ul>
                 </div>
                </div>
            
              </a>
              </div>
            </div>

           <div className="col-md-4 col-xs-12 catListingDiv">
              <div className="catListingDivIn">
              <a href="javascript:void(0)">
                <div className='paperSource'>
                    <div className='paperSourceName'><strong>Source: </strong>Times of India</div>
                    <div className='paperLang'><span>English</span></div>
                </div>
                <div className="catListImg"><img src={news01} alt="" /></div>
                <div className="catListCnt">
                    <div className='posNegLine'>
                        <div className='positiveRtng'><span>Positive: <b>90%</b></span></div>
                        <div className='negtvRtng'><span>Negative: <b>10%</b></span></div>
                    </div>
                <div className="dateTmDiv">
                <div className="dIn"><CalendarCheck size={18} /> Date: <span>02 Nov 2020</span></div>
                <div className="tIn"><Clock size={18} /> Time: <span> 04:00 PM</span></div>
                </div>
                 <h2>PM Modi: The Architect Of New India</h2>
                 <p>Under his leadership, the country is realizing the dream of 'One India Great India', says CM Yogi Adityanath</p>
                 <div className="lstHsTg">
                   <ul>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                   </ul>
                 </div>
                </div>
            
              </a>
              </div>
            </div>
            <div className="col-md-4 col-xs-12 catListingDiv">
              <div className="catListingDivIn">
              <a href="javascript:void(0)">
                <div className='paperSource'>
                    <div className='paperSourceName'><strong>Source: </strong>Times of India</div>
                    <div className='paperLang'><span>English</span></div>
                </div>
                <div className="catListImg"><img src={news01} alt="" /></div>
                <div className="catListCnt">
                    <div className='posNegLine'>
                        <div className='positiveRtng'><span>Positive: <b>90%</b></span></div>
                        <div className='negtvRtng'><span>Negative: <b>10%</b></span></div>
                    </div>
                <div className="dateTmDiv">
                <div className="dIn"><CalendarCheck size={18} /> Date: <span>02 Nov 2020</span></div>
                <div className="tIn"><Clock size={18} /> Time: <span> 04:00 PM</span></div>
                </div>
                 <h2>PM Modi: The Architect Of New India</h2>
                 <p>Under his leadership, the country is realizing the dream of 'One India Great India', says CM Yogi Adityanath</p>
                 <div className="lstHsTg">
                   <ul>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                   </ul>
                 </div>
                </div>
            
              </a>
              </div>
            </div>
            <div className='col-md-12 hdrPag'>
                    <ul>
                        <li><a href="" className='prvtBtn'><ArrowLeft size={17} /></a></li>
                        <li><a href="" className='pagactive'>1</a></li>
                        <li><a href="">2</a></li>
                        <li><a href="">3</a></li>
                        <li><a href="">4</a></li>
                        <li><a href="">5</a></li>
                        <li><a href="">6</a></li>
                        <li><a href="" className='nextBtn'><ArrowRight size={17} /></a></li>
                    </ul>
                </div>
        </div>
        </div>
        </div>
    </div>
  )
}

export default NewsLanding