import React from "react";
import Table from 'react-bootstrap/Table';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
  } from 'chart.js';
import { Bar } from 'react-chartjs-2';

// import CanvasJSReact from '@canvasjs/react-charts';
import landsliderimg from '../../assets/images/newspaper/NewsAggregator_Layout_Banner.jpg'
import newsGrph1 from '../../assets/images/newspaper/statsIcn.png'
import newsGrph2 from '../../assets/images/newspaper/statsIcngreen.png'
import newsGrph3 from '../../assets/images/newspaper/statsIcnbl.png'
import newsGrph4 from '../../assets/images/newspaper/statsIcnrd.png'
import { CheckCircle, Microphone, Newspaper, SortAscending, ThumbsDown, ThumbsUp } from "phosphor-react";
import { BiCalendarCheck } from "react-icons/bi";
// import faker from 'faker';
function NewsDashboardpie(){
    ChartJS.register(
        CategoryScale,
        LinearScale,
        BarElement,
        Title,
        Tooltip,
        Legend
      );
    // var CanvasJS = CanvasJSReact.CanvasJS;
    // var CanvasJSChart = CanvasJSReact.CanvasJSChart;
    
     const options = {
        plugins: {
          title: {
            display: true,
            text: '',
          },
        },
        responsive: true,
        scales: {
          x: {
            stacked: true,
          },
          y: {
            stacked: true,
          },
        },
      };




const labels = ['Jan', 'Feb', 'March', 'April', 'May', 'June', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const data = {
    labels,
    datasets: [
      {
        label: 'Positive',
        data: [146, 48, 644, 18, 911, 656, 232, 146, 48, 644, 18, 911],
        backgroundColor: 'rgb(25, 134, 255)',
       
      },
      {
        label: 'Negative',
        data: [146, 48, 644, 18, 911, 656, 232, 146, 48, 644, 18, 911],
        backgroundColor: 'rgb(255, 99, 132)',
      },
    //   {
    //     label: 'Dataset 3',
    //     data: [146, 48, 644, 18, 911, 656, 232],
    //     backgroundColor: 'rgb(53, 162, 235)',
    //   },
    ],
    
  };
  const data2 = {
    labels,
    datasets: [
      {
        label: 'Positive',
        data: [146, 48, 644, 18, 911, 656, 232, 146, 48, 644, 18, 911],
        backgroundColor: 'rgb(25, 134, 255)',
       
      },

    //   {
    //     label: 'Dataset 3',
    //     data: [146, 48, 644, 18, 911, 656, 232],
    //     backgroundColor: 'rgb(53, 162, 235)',
    //   },
    ],
  };
  const data3 = {
    labels,
    datasets: [
      {
        label: 'Negative',
        data: [146, 48, 644, 18, 911, 656, 232, 146, 48, 644, 18, 911],
        backgroundColor: 'rgb(255, 99, 132)',
      },
    //   {
    //     label: 'Dataset 3',
    //     data: [146, 48, 644, 18, 911, 656, 232],
    //     backgroundColor: 'rgb(53, 162, 235)',
    //   },
    ],
  };
return(

    <div className="landingSrch">
    <div className="landingSliderDiv"><img src={landsliderimg} alt="" />
        <div className='magicEyeTtl'> <span>Magic Eye</span></div>
    </div>
<div className="newsDashbrdCnt">
    <div className="container">
    <div className='newsSrchSec'>
        <form action="">
            <div className='topSrchDiv'>
                <div className='row'>
                <div className='form-group col-md-11 col-xs-12 wrtKeywrds'>
                    <input type="text" className='form-control' placeholder='Write Keywords Here ...' />
                    <span className='voiceCl'><Microphone size={22} /></span>
                </div>

                <div className='form-group col-md-1 col-xs-12'>
                    <button className='button green btn-login-signup'>Search</button>
                </div>
                </div>
            </div>
        </form>
        </div>
        <div className='lstngFltr newsDshbrdFltrDiv'>
                    <form action="">
                        <div className='fltrInpt'>
                        <input type="radio" name='filter' /> <span>Last 7 days</span>
                        </div>
                        <div className='fltrInpt'>
                        <input type="radio" name='filter' /> <span>Last 15 days</span>
                        </div>
                        <div className='fltrInpt'>
                        <input type="radio" name='filter' /> <span>Last 30 days</span>
                        </div>
                        <div className='fltrInpt fromDate'>
                         <span>From Date</span> <input type="text" className='form-control inptClndr' /> <BiCalendarCheck size={32} className='dtIcnn' />
                        </div>
                        <div className='fltrInpt fromDate todate'>
                         <span>To Date</span> <input type="text" className='form-control inptClndr' /> <BiCalendarCheck size={32} className='dtIcnn' />
                        </div>
                        <div className='fltrInpt'>
                         <button className='srchBtnn'>Filter</button>
                        </div>
                    </form>
                </div>

        <h2 className="newsHdng">All India Stats</h2>
        <div className='col-md-12 lstUpdate'>
                    <span>Last Updated At: 14 Nov 2023 04:15 PM</span>
                </div>
        <div className="newsStatsBx">
            <div className="row">
            <div className="col-md-6 col-xs-12 statsBx1 totalNews">
                <div className="statsBx1In">
                    <h2>Total News <span>2500</span></h2>
                    <h3 className="nwsGrphIcn"><img src={newsGrph1} alt="" /></h3>
                    <span className="newsIcnCat"><Newspaper size={32} /></span>
                </div>
            </div>
            <div className="col-md-6 col-xs-12 statsBx1 postvNws">
                <div className="statsBx1In">
                    <h2>Positive News <span>2000</span></h2>
                    <h3 className="nwsGrphIcn"><img src={newsGrph2} alt="" /></h3>
                    <span className="newsIcnCat"><ThumbsUp size={32} /></span>
                </div>
            </div>
            <div className="col-md-6 col-xs-12 statsBx1 negNws neturalNws">
                <div className="statsBx1In">
                    <h2>Neutral News <span>300</span></h2>
                    <h3 className="nwsGrphIcn"><img src={newsGrph3} alt="" /></h3>
                    <span className="newsIcnCat"><ThumbsDown size={32} /></span>
                </div>
            </div>
            <div className="col-md-6 col-xs-12 statsBx1 negNws">
                <div className="statsBx1In">
                    <h2>Negative News <span>200</span></h2>
                    <h3 className="nwsGrphIcn"><img src={newsGrph4} alt="" /></h3>
                    <span className="newsIcnCat"><ThumbsDown size={32} /></span>
                </div>
            </div>
            </div>
        </div>

                {/* <div className="tblGrphBtm">
                    <div className="row">
                    
                    <div className="col-md-7 col-xs-12 tblDiv">
                        <div className="tblDivIn">
                            <h4 className="tblSbHdng">India</h4>
                            <div className="dashbrdKeywordnews">
                            <div className="lstHsTg">
                   <ul>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                     <li>#Architect</li>
                     <li>#Leadership</li>
                     <li>#Country</li>
                     <li>#Greatleaders</li>
                     <li>#Goal</li>
                     <li>#Universe</li>
                     <li>#Institutions</li>
                   </ul>
                 </div>
                            </div>
                            <Table responsive="sm" className="table table-striped dashnwsTbl">
        <thead>
          <tr>
            
            <th>Positive News <SortAscending size={26} /></th>
            <th>Neutral News <SortAscending size={26} /></th>
            <th>Negative News <SortAscending size={26} /></th>
            <th>Total News <SortAscending size={26} /></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>65 </td>
            <td>55</td>
            <td>45</td>
            <td>165</td>
          </tr>
          
          
        </tbody>
      </Table>
                        </div>
                    </div>
                    <div className="col-md-5 col-xs-12 tblDiv grphDiv">
                        <div className="grphDivIn totalNws">
                        <h4 class="tblSbHdng">Report Overview</h4>
                        <div className="totalnwsGrph totalnewsin">
			
            <Bar options={options} data={data} />
				
		</div>
        <div className="grphDivIn postvNews">
     <h4 class="tblSbHdng">Positive News</h4>
     <div className="totalnwsGrph positivenewsin">
     <Bar options={options} data={data2} />
    </div>
    </div>
    <div className="grphDivIn negtNws">
     <h4 class="tblSbHdng">Negative News</h4>
     <div className="totalnwsGrph negativenewsin">
     <Bar options={options} data={data3} />
      </div>
    </div>
                        </div>
                    </div>
                </div>
                </div> */}
    </div>
</div>
    </div>

)
}
export default NewsDashboardpie