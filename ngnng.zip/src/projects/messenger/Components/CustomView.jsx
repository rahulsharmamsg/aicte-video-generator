// App.js

import React, { useState } from 'react';
import CustomFileUploadButton from './CustomFileUploadButton';
import DisplayImage from './DisplayImage';
import avatar from "../../../assets/images/avatar.gif"

const CustomView = () => {
  const [imageUrl, setImageUrl] = useState('');

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      setImageUrl(reader.result);
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className='viewFile'>
      <div className="viewImg w-100 mb-3">
      <DisplayImage imageUrl={imageUrl?imageUrl:avatar} />
      </div>
      <CustomFileUploadButton onChange={handleFileChange} />      
    </div>
  );
};

export default CustomView;
