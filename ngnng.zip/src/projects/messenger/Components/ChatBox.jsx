import React,{ useState } from 'react'
import { Form ,Modal,Button} from "react-bootstrap"
import {BsFillSendFill,BsFileImage,BsMicFill,BsFillPlayFill,BsFillPauseFill} from "react-icons/bs"
import {AiOutlinePlus,AiOutlineAudio, AiOutlineCamera,AiFillFileImage} from "react-icons/ai"
import {Dropdown, DropdownButton} from "react-bootstrap"
import Profile from './Profile';
import { Link } from 'react-router-dom'

function ChatBox() {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [voice, setVoice] = useState(false);
    const handleVoice = () =>{
        setVoice(!voice);
    }

  return (
    <>
      <div className='fixedForm'>
      {voice ? 
          <div className='recordVoice'>
            <ul className='d-flex justify-content-end'>
                <li><Link><BsFillPlayFill color='#fff' size={20} onClick={handleVoice}/></Link></li>
                <li><Link><BsFillPauseFill color='#fff' size={20} onClick={handleVoice}/></Link></li>
            </ul>
            </div>
         :null}
      <Form className='d-flex justify-content-start'>
         <Form.Control type='text' placeholder='Write somthing here' rows={3} />         
         <button type='button' className='startbtn' onClick={handleVoice}><BsMicFill size={20}/></button>
        <Dropdown>
        <Dropdown.Toggle id="dropdown-button-dark-example1">
           <AiOutlinePlus size={20}/>
        </Dropdown.Toggle>
        <Dropdown.Menu>
          {/* <Dropdown.Item href="#/action-1" active><AiOutlineAudio size={20}/> Audio</Dropdown.Item> */}
          <Dropdown.Item href="#/action-2" onClick={handleShow}><AiOutlineCamera size={20}/> Camera</Dropdown.Item>
          <Dropdown.Item href="#/action-3" className="imageupload"><input type="file" name="myfile" accept="image/png, image/gif, image/jpeg"/><span className='fileUp'><BsFileImage size={20}/> Images</span></Dropdown.Item>         
          <Dropdown.Item href="#/action-4" className="fileupload"><input type="file" name="myfile" /><span className='fileUp'><AiFillFileImage size={20}/>  File</span></Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
        <button className='send button green'><BsFillSendFill size={20}/></button>
      </Form>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Camera</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Profile/>
        </Modal.Body>
        {/* <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer> */}
      </Modal>
      </div>
    </>
  )
}

export default ChatBox
