// DisplayImage.js

import React from 'react';

const DisplayImage = ({ imageUrl }) => {
  return imageUrl ? <img src={imageUrl} alt="Uploaded" className='showimg'/> : <img src={imageUrl} alt="Uploaded" className='showimg' />;
};

export default DisplayImage;
