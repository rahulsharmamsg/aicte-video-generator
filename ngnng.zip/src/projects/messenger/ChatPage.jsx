import React from 'react'
import ChatSidebar from './Components/ChatSidebar'
import ChatArea from './Components/ChatArea'
import ChatBox from './Components/ChatBox'

function ChatPage() {
  return (
    <>
    <main className='content-area'>
      <section className='chatbars'>
            <div className='chatSidebar'>
                <ChatSidebar/>
            </div>
            <div className='chats'>
              <ChatArea/>
              <ChatBox/>
            </div>
      </section>
    </main>
    </>
  )
}

export default ChatPage