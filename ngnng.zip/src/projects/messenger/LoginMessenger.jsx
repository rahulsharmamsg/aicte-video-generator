import React from "react";
import "../messenger/custom.css";
import { useNavigate } from "react-router-dom";
import { Button, Container, Form } from "react-bootstrap";
import { BiUserCircle, BiLogInCircle, BiLogOutCircle } from "react-icons/bi";

function LoginMessenger() {
    let navigate = useNavigate(); 
  const routeChange = () =>{ 
    let path = `SignupMessenger`; 
    navigate(path);
  }
  return (
    <>
      <main className="contentarea">
        <section className="loginpage">
          <Container>
            <div className="login">
              <div className="usericon">
                <BiUserCircle size={90} />
              </div>
              <Form>
                <Form.Group className="d-flex justify-content-start">
                  <Form.Select
                    style={{ width: "20%", marginRight: 10}}
                    autocomplete="off">
                    <option value="0"></option>
                  </Form.Select>
                  <Form.Control type="number" />
                </Form.Group>
                <Form.Group className="text-start mt-3">
                  <Form.Label>Password</Form.Label>
                  <Form.Control type="password" autocomplete="off" />
                </Form.Group>
                <Form.Group className="mt-3">
                  <Button className="logbtn button green">
                    <BiLogInCircle size={20} />
                    Login
                  </Button>
                </Form.Group>
                <Form.Group>
                  <p>OR</p>
                </Form.Group>
                <Form.Group>
                  <Button className="logbtn button orange" onClick={routeChange}>
                    <BiLogOutCircle size={20} />
                    Signup
                  </Button>
                </Form.Group>
              </Form>
            </div>
          </Container>
        </section>
      </main>
    </>
  );
}

export default LoginMessenger;
