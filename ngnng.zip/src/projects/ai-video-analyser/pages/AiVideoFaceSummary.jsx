import React, { useEffect, useState, useRef} from "react"; 
import { Modal, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import Webcam from "react-webcam";

import {Progress} from 'react-sweet-progress'
import { VideoCamera } from "phosphor-react";
import { useNavigate } from "react-router-dom";
import axios from "axios";


function AiVideoAnalyser() {
  const [show, setShow] = useState(false);
  const [lang, setLang] = useState('en-IN');
//   const [videoorigin, setVideoorigin] = useState(0);// eslint-disable-line no-use-before-define
  const [videourl, setVideourl] = useState();
  const [video, setVideo] = useState();
  const [isloading,serIsloading] = useState(false)
  const [Recordedvideo, setRecordedVideo] = useState();// eslint-disable-line no-use-before-define
  const [isRecording, setIsRecording] = useState(false);
  const [recordedChunks, setRecordedChunks] = useState([]);
  const [timer, settimer] = useState(100);
  const [blobLoading,setBlobLoading] = useState(false)
  const [aud,setAud] = useState()
  const webcamRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const handleClose = () => setShow(false);
  const handleShow = () => {
    setShow(true);
  };
  let navigate = useNavigate();

  const studentData = null
  const  setVideoData  = null
  const handleSubmit = () => {
    serIsloading(true)
    let videoData = null
   




    let formData = new FormData();
    formData.append("file",video);

  
    // console.log("formdata=", forms);
// Fetch the Blob data from the URL
fetch(videourl)
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.blob();
  })
  .then(blobData => {
    // Store the Blob data in the videofile variable
    let videofile = blobData;

    // Create a Blob with the correct MIME type (e.g., video/mp4)
    var videoBlob = new Blob([videofile], { type: 'video/mp3' });

    // Create a data URL for the Blob
    videoData = URL.createObjectURL(videoBlob);

    // You can now use videoDataURL as a data URL for the video file
    console.log('Data URL for the video file:', videoData);

    // If you want to display the video in an HTML video element, you can set the src attribute
    // var videoElement = document.getElementById('your-video-element-id');
    // videoElement.src = videoDataURL;
  })
  .catch(error => {
    console.error('Error fetching Blob data:', error);
  });
    
    // let fileName2 = `vid.mp4`;
    // let videes = new Blob([videourl], { type: 'video/mp4' });
 
    // formData.append("tokens", "positive" );

    let formData2 = new FormData();
    // const blob = new Blob([video],{type: 'audio/wav'})
    let fileName = `aud`;
    let files = new File([aud], fileName);
    formData2.append("file", files)
    formData2.append("language",lang)
    

    axios.post('https://voiceapi.aicte-india.org/voice-to-text',formData2)
    .then(async res=>{
      const post = {
        outputLang:'en-IN',
        text:res?.data.data 
      }
      let text = res?.data.data
      localStorage.setItem('transcript',res?.data.data)
      axios.post('https://voiceapi.aicte-india.org/text-to-text',post)
      .then(res=>{
        const post = {
          text:res?.data.data
        }
        
        axios.post("https://anuvadiniqa.aicte-india.org/face/analyze_text",post)
        .then(async res=>{
          formData.append("text", text);
          formData.append("tone", res?.data?.result?.tone);
     

          await axios.post("https://anuvadiniqa.aicte-india.org/face/upload_vid_blank", formData, {})
        .then((res) => {
          if (res.data.status == "success") {
            localStorage.setItem("reasponse", JSON.stringify(res.data.result));
            navigate("/video/AiDiscription");
          }
        })
        .catch((err) => {
          console.log(err, `error`);
          serIsloading(true)
        });
        })
      })
      .catch(err=>{
        console.log(err)
        serIsloading(true)
      })
    })
    .catch(err=>{console.log(err)})
    
  };
  function checkVideoDuration(file) {
    var video = document.createElement("video");
    video.preload = "metadata";
    video.onloadedmetadata = function () {
      window.URL.revokeObjectURL(video.src);
      var duration = video.duration;
      if (duration <= 15) {
        // console.log("Video is less than or equal to 15 seconds long");
      } else {
        alert("Video is longer than 15 seconds");
        setVideourl()
        setVideo()
      }
    };
    video.src = URL.createObjectURL(file);
  }

  const createAudio = (file) =>{
    setBlobLoading(true)
    if (file) {
      try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  
        // Create a FileReader to read the selected file
        const fileReader = new FileReader();
        fileReader.readAsArrayBuffer(file);
  
        fileReader.onload = async () => {
          const arrayBuffer = fileReader.result;
          const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
  
          // Create a MediaStream destination node to capture audio
          const destinationNode = audioContext.createMediaStreamDestination();
          const sourceNode = audioContext.createBufferSource();
          sourceNode.buffer = audioBuffer;
          sourceNode.connect(destinationNode);
          sourceNode.start();
  
          // Create a MediaRecorder to capture the audio stream
          const mediaRecorder = new MediaRecorder(destinationNode.stream);
  
          const chunks = [];
          mediaRecorder.ondataavailable = (e) => {
            if (e.data.size > 0) {
              chunks.push(e.data);
            }
          };
  
          mediaRecorder.onstop = () => {
            // Combine the captured audio chunks into a Blob
            const audioBlob = new Blob(chunks, { type: 'audio/wav' });
            
  
            // Do something with the audioBlob (e.g., upload it, process it, etc.)
            console.log(audioBlob);
            setAud(audioBlob)
       
            if(audioBlob){
              setBlobLoading(false)
            }
            // Clean up resources
            audioContext.close();
          };
  
          // Start recording
          mediaRecorder.start();
  
          // Stop recording after a short duration (adjust as needed)
          setTimeout(() => {
            mediaRecorder.stop();
          }, 15000); // Recording for 5 seconds
        };
      } catch (error) {
        console.error('Error:', error);
      }
    }
  }

  const handleFile = (e) => {
    let files = e.target.files;
    if (files.length === 1) {
      let file = files[0];
    
      
      console.log(file,"file details");
      // setBlobLoading(true)
      createAudio(file)
      setVideourl(URL.createObjectURL(file));
      setVideo(file)
      checkVideoDuration(file);
    }

    let allowedExtensions = ["webm", "mp4"];
    if (!allowedExtensions.includes(e.target.files[0].type.split("/")[1])) {
      alert("Only webm,mp4 Video file allowed");
      e.target.files[0] = "";
    } else {
      setVideo(e.target.files[0]);
    }
  };
  useEffect(() => {
    
    setRecordedVideo(localStorage.getItem("recordedVideo"));
  }, [videourl]);
  const handleStartRecording = () => {
    setIsRecording(true);
    setRecordedChunks([]);
    Countdown()

    const stream = webcamRef.current.stream;
    mediaRecorderRef.current = new MediaRecorder(stream);

    mediaRecorderRef.current.ondataavailable = event => {
      if (event.data.size > 0) {
     
        setRecordedChunks(prevChunks => [...prevChunks, event.data]);
        // setVideoData(prevChunks => [...prevChunks, event.data]);
      }
    };

    mediaRecorderRef.current.start();
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      const blob = new Blob(recordedChunks, { type: 'video/mp4' });
      // const audioBlob = new Blob(recordedChunks, { type: 'audio/wav' });
      const url = URL.createObjectURL(blob);
      // setAud(audioBlob)
      // setVideourl(url)
      // setShow(false)
      // const file = new File([blob],'video')
      // createAudio(file)
    //   setVideourl(URL.createObjectURL(file));
    //   setVideo(file)
    //   checkVideoDuration(file);
    }
  };

  const handleDownload = () => {
    const blob = new Blob(recordedChunks, { type: 'video/mp4' });
    // const blob2 = new Blob(recordedChunks, { type: 'audio/wav' });
    const url = URL.createObjectURL(blob);
    // const a = document.createElement('a');
    // a.style.display = 'none';
    // a.href = url;
    // a.download = 'recorded-video.mp4';
    // document.body.appendChild(a);
    // setVideourl(url)
    // setVideo(url)
    // setAud(blob2)
    // setVid(blob)
    // // a.click();
    // window.URL.revokeObjectURL(url);
    // document.body.removeChild(a);
    const file = new File([blob],'video')
      createAudio(file)
      setVideourl(URL.createObjectURL(file));
      setVideo(file)
      // checkVideoDuration(file);
      setShow(false)
  };

//   const ShareData = () => {
//     const blob = new Blob(recordedChunks, { type: 'video/mp4' });
//     const url = URL.createObjectURL(blob);
//     setVideoData(url);
//     checkVideoDuration(url)
 
     
//   };
  const Countdown = () => {
    let i = 100;
    let interval = setInterval(() => {
        settimer(i)
        i--;
        if (i < 0) {
            clearInterval(interval);
            handleStopRecording()
        }
    }, 150);
  }

  useEffect(() => {
    setLang(localStorage.getItem('selectedLang'))
  }, [])
  
  console.log(studentData,"57890765890756789075678907658 studentData")
  return (
    <>
      <main className="contentarea">
        <div className="banner-allpage-sec">
          <ul className="breadcrumb">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li><Link to="/video/">Video</Link></li>
          <li><Link to="/video/">Ai video Analyser</Link></li>

        
          </ul> 
          <div className="banner-content-sec text-center">
            <h1 className="first-head">AI Video Analyser</h1>
            <h3 className="second-head">Analyze facial expressions in real-time from any video and gain insights into emotions with just a few clicks. Understand the feelings behind every smile, frown, and more.</h3>
            <br/>            
            
        </div>
        </div>
        <section className="selectlang">
          <div className="container">
            {isloading===true?     <>
                        <div className='container' style={{ textAlign: "center", marginTop: -120, position: "relative", marginBottom: 50 }}>
                            <div class="stepFour clickForFive" style={{ borderRadius: 10, background: "rgb(190, 227, 248)", padding: 50, width: "100%", margin: "auto" }}>
                                <p class="chakra-text">
                                    {/* <img src="./assets/images/loader_bagic.gif" alt="" style={{ width: 65 }} /> */}
                                    <div className="loader"></div>
                                    </p>
                                <div class="chakra-heading" style={{ fontSize: 20, fontWeight: "bold" }}>Your Video file is being processed...</div>
                                <p class="chakra-text">This may take some time. Stay on this page or come back later to get the result.</p>
                            </div>
                        </div>
                    </>:<>
                    <div className="row">
              <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                <div className="uploadFile useBorder">
                  <div className="upload-btn-wrapper">
                    <a
                      className="button orange btn"
                      href="/face-analyser/PassportPhotoMaker"
                      style={{
                        fontSize: 26,
                        borderRadius: 10,
                        padding: "15px 30px",
                      }}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="32"
                        height="32"
                        fill="currentColor"
                        viewBox="0 0 256 256"
                      >
                        <rect width="256" height="256" fill="none"></rect>
                        <polyline
                          points="86 82 128 40 170 82"
                          fill="none"
                          stroke="currentColor"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="16"
                        ></polyline>
                        <line
                          x1="128"
                          y1="152"
                          x2="128"
                          y2="40"
                          fill="none"
                          stroke="currentColor"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="16"
                        ></line>
                        <path
                          d="M216,152v56a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V152"
                          fill="none"
                          stroke="currentColor"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="16"
                        ></path>
                      </svg>
                      Upload Video
                    </a>
                    <input
                      type="file"
                      name="myfile"
                      onChange={(e) => handleFile(e)}
                    />
                  </div>
                  
                </div>
                <span>Please upload only videos of less than 15 seconds.</span>
              </div>
              <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                <div className="useBorder">
                  <Button variant="primary" onClick={handleShow}>
                    <VideoCamera size={28} /> Record
                  </Button>
                  <Modal show={show} onHide={handleClose}>
                    <Modal.Header closeButton>
                      <Modal.Title>Recording</Modal.Title>
                    </Modal.Header>
                    <Modal.Body className="p-3 text-center">
                      {/* <VideoRecorder  /> */}
                      <Webcam
                        audio={true}
                        mirrored={true}
                        ref={webcamRef}
                        videoConstraints={{
                          width: 1280,
                          height: 720,
                          facingMode: "user",
                        }}
                      />

                      {isRecording ? (
                        <>
                          <Progress percent={timer} />
                          <button
                            className="button orange"
                            onClick={handleStopRecording}
                          >
                            Stop Recording
                          </button>
                        </>
                      ) : (
                        <button
                          className="button green"
                          onClick={handleStartRecording}
                        >
                          Start Recording
                        </button>
                      )}

                      {recordedChunks.length > 0 && (
                        <button
                          className="button orange"
                          style={{ marginLeft: 10 }}
                          onClick={handleDownload}
                        >
                          Upload Recording
                        </button>
                      )}
                    </Modal.Body>
                  </Modal>
                </div>
              </div>
            </div>

            {videourl && (
              <div className="mt-4">
                {/* <ReactPlayer url={[
     {src: videourl.videoFileURL, type: 'video/mp4'}
 
   ]} />
   */}
                <div className="max-width-800 m-auto">
                  <video
                    src={videourl}
                    typeof="video/mp4"
                    autoPlay={true}
                    controls={true}
                    duta
                  />
                </div>
              </div>
            )}
            <div className="mt-4">
              {
                blobLoading?
                <div className="loader">

                </div>:
                <Button
                type="button"
                className="button green"
                onClick={handleSubmit}
              >
                Submit
              </Button>
              }
              
            </div></>}
         
          </div>
        </section>
      </main>
    </>
  );
}

export default AiVideoAnalyser;
