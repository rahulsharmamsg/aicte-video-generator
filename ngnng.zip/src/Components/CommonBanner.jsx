import React from 'react'
import { UploadSimple } from 'phosphor-react'
import { Link } from 'react-router-dom'

const CommonBanner = (props) => {
  return (
    <>
       <div className="banner-allpage-sec">
        <div className="banner-content-sec text-center">
            <h1 className="first-head">{props.title} <br /> {props.ttitle}</h1>
            <h3 className="second-head">{props.stitle}</h3>
            <br/>
            <Link to="/ImageEditor" className="button orange" style={{fontSize:26, borderRadius:10, padding:"15px 30px"}}>
            <UploadSimple size={32} />
                Upload Image
            </Link>
            <p className="txt-eg">{props.para}</p>
        </div>
    </div>
    </>
  )
}

export default CommonBanner
