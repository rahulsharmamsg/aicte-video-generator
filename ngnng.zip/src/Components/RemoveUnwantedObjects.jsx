import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'
import unwant1 from "../assets/images/image/object/1.jpg"
import unwant2 from "../assets/images/image/object/2.jpg"
import unwant3 from "../assets/images/image/object/4.jpg"

const RemoveUnwantedObjects = () => {
  return (
    <>
    <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Image</li>
            <li>Remove Unwanted Objects</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Remove Unwanted Objects</h1>
            <h3 className="second-head">Fast, simple and easy to use tool you'll love.</h3>
            <br/>
            <Link to="" className="button orange btn" style={{fontSize:26, borderRadius:10, padding:"15px 30px"}}>
            {/* <UploadSimple size={32} /> */}
                Coming soon...
            </Link>
            {/* <input type="file" name='myFile' onChange={HandleBg} /> */}
          
            {/* <p className="txt-eg">or drop a file here CTRL+V to paste image or URL</p> */}
        </div>
    </div>
    <section style={{textAlign:"center", marginTop:-40, position:"relative"}}>
        <div class="secRUOImg">
            <img src={unwant1} alt="window" width="480" height="340"/>             
        </div>
    </section>
    <section class="features-homepage-sec">
            <div class="page-container">
                <div class="main-container">
                   
                    <div class="feature-box-sec row">
                        <div class="col-lg-6">
                            <h4 class="feature-name-head">With inpainting algorithm powered by artificial intelligence</h4>
                            <p>You are enabled to easily roll back years from old photos by erasing scratches, spots and tears. Bring the old days back to life!</p>                            
                        </div>
                        <div class="col-lg-6">
                            <img src={unwant2} alt=""/>
                        </div>
                    </div>
                    <div class="feature-box-sec row">
                        <div class="col-lg-6">
                        <img src={unwant3} alt=""/>
                        
                        </div>
                        <div class="col-lg-6">
                            <h4 class="feature-name-head">There are such moments when strangers get into your travel photos</h4>
                            <p>No worries! The cutout.pro inpaint tool will make tourists or other unwanted people disappear magically. We are here to help bring back the good memories.</p>
                            
                        </div>                
                    </div>
                   
                </div>
            </div>
        </section>
    <Safe/>
    <WhyChoose/>
    <Faq/>
    </>
  )
}

export default RemoveUnwantedObjects