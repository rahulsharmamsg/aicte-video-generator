import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const VoiceBasedMultilingualForm = () => {
  return (
    <>
      <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link href="/">Home</Link></li>
            <li>Translation</li>
            <li>Voice Based Multilingual Form</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Voice Based Multilingual Form</h1>
            <h3 className="second-head"></h3>
        </div>
    </div>
    <Safe/>
    <WhyChoose/>
    <Faq/>
    </>
  )
}

export default VoiceBasedMultilingualForm
