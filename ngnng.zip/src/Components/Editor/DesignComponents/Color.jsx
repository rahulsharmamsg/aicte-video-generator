import React from 'react'

function Color() {
  return (
    <>
      <div className="color-component-sec">    
    <div className="color-palette-box">
        <div className="heading">Default Colors</div>
        <div className="color-picker">
            <span className="color-item" style={{backgroundColor:"#ffffff"}}></span>
            <span className="color-item" style={{backgroundColor:"#000000"}}></span>
            <span className="color-item" style={{backgroundColor:"#545454"}}></span>
            <span className="color-item" style={{backgroundColor:"#737373"}}></span>
            <span className="color-item" style={{backgroundColor:"#a6a6a6"}}></span>
            <span className="color-item" style={{backgroundColor:"#d9d9d9"}}></span>            
            <span className="color-item" style={{backgroundColor:"#ff1616"}}></span>
            <span className="color-item" style={{backgroundColor:"#ff5757"}}></span>
            <span className="color-item" style={{backgroundColor:"#ff66c4"}}></span>
            <span className="color-item" style={{backgroundColor:"#cb6ce6"}}></span>
            <span className="color-item" style={{backgroundColor:"#8c52ff"}}></span>
            <span className="color-item" style={{backgroundColor:"#5e17eb"}}></span>
            <span className="color-item" style={{backgroundColor:"#03989e"}}></span>
            <span className="color-item" style={{backgroundColor:"#00c2cb"}}></span>
            <span className="color-item" style={{backgroundColor:"#5ce1e6"}}></span>
            <span className="color-item" style={{backgroundColor:"#38b6ff"}}></span>
            <span className="color-item" style={{backgroundColor:"#4592ff"}}></span>
            <span className="color-item" style={{backgroundColor:"#004aad"}}></span>
            <span className="color-item" style={{backgroundColor:"#008037"}}></span>
            <span className="color-item" style={{backgroundColor:"#7ed957"}}></span>
            <span className="color-item" style={{backgroundColor:"#c9e265"}}></span>
            <span className="color-item" style={{backgroundColor:"#ffde59"}}></span>
            <span className="color-item" style={{backgroundColor:"#ffbd59"}}></span>
            <span className="color-item" style={{backgroundColor:"#ff914d"}}></span>
            <span className="color-item" style={{backgroundColor:"#f79af2"}}></span>
        </div>
    </div>
    <div className="color-palette-box">
        <div className="heading">Custom Colors</div>
        <div className="color-picker">
            <span className="color-item">
                <span className="custom-color-btn">
                    <div className="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M12.75 11.25V5a.75.75 0 1 0-1.5 0v6.25H5a.75.75 0 1 0 0 1.5h6.25V19a.75.75 0 1 0 1.5 0v-6.25H19a.75.75 0 1 0 0-1.5h-6.25z"></path></svg>
                    </div>
                </span>
            </span>
        </div>
    </div>
</div>

    </>
  )
}

export default Color
