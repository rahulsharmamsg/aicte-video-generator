import React from 'react'

function AddText() {
  return (
    <>
      <div className="addTextComponentSec">    
    <div className="addTextBox">
        <button title="" className="button orange btn_viewAll">+ Add Text</button><br/>
        <div className="addTextPicker">  
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EAD87yXxksg/2/0/308w-8FuyHxXSZ5c.png" alt="" draggable="false"/>
            </span>
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EADYfsBCn6U/1/0/548w-SjMRl0LP1JA.png" alt=""/>
            </span>
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EAD873X3OjU/2/0/546w-MMzEBwRDIxo.png" alt="" draggable="false"/>
            </span>
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EADYfmQNsWY/1/0/340w-mGPfPboRvr0.png" alt="" draggable="false"/>
            </span>
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EAD88Pg4mPI/1/0/378w-CE7SdnTVCBI.png" alt=""/>
            </span>
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EAD87wrs7KI/2/0/456w-Q5W2IPamyWU.png" alt=""/>
            </span>
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EAD88K47MnU/1/0/784w-2RDoPYu9VsU.png" alt="" draggable="false"/>
            </span>
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EADYfiUXi-I/1/0/366w-PZ9Vb8xAzYU.png" alt="" draggable="false"/>
            </span>
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EADYfpquC6w/1/0/234w-zxU8yct3CUM.png" alt=""/>
            </span>
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EAD87zPzQq4/1/0/792w-lPsI4nF7qZA.png" alt="" draggable="false"/>
            </span>
            <span className="addTextOption">
                <img className="" src="https://template.canva.com/EAD87626Qjs/2/0/504w-CPY6EB0J3kU.png" alt="" draggable="false"/>
            </span>            
        </div>
        <button title="" className="button btn_viewAll">Show all Text</button>
    </div>
</div>

    </>
  )
}

export default AddText
