import React from 'react'

function CurveText() {
  return (
    <>
      <div className="curveTextComponentSec">    
    <div className="curveTextBox">
        <div className="curveTextPicker">            
            <span className="curveTextOption">
                <img className="" src="../assets/images/thumb/text/curve/thumb_curve-text.jpg" alt="" draggable="false"/>
            </span>
            <span className="curveTextOption">
                <img className="" src="../assets/images/thumb/text/curve/thumb_curve-text-top.jpg" alt=""/>
            </span>
            <span className="curveTextOption">
                <img className="" src="../assets/images/thumb/text/curve/thumb_curve-text-bottom.jpg" alt=""/>
            </span>
        </div>
        <div className="rangeBox">                
            <div className="rangeName">Diameter</div>
            <div className="rangeBar">
                <input className="" type="range" min="0" max="100" value="50"/>
            </div>
        </div>
        <div className="rangeBox">                
            <div className="rangeName">Kerning</div>
            <div className="rangeBar">
                <input className="" type="range" min="0" max="100" value="50"/>
            </div>
        </div>
    </div>
</div>

    </>
  )
}

export default CurveText
