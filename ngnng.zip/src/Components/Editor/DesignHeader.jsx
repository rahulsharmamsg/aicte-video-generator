import React from 'react'
import { Link } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'

function DesignHeader() {
    const navigate = useNavigate();
  return (
    <>      
        <header className='desgnHead'>
            <div className="row">
                <div className="logo-sec col-lg-2">           
                    <button className="btn_back" onClick={() => navigate(-1)}>
                        <svg viewBox="0 0 16 16" width="16" height="16"><g transform="matrix(1.6,0,0,1.6,0,0)"><path d="M7.25,9.5,2.9,5.354a.5.5,0,0,1,0-.708L7.25.5" fill="none" stroke="#fff" strokeLinecap="round" strokeLinejoin="round"></path></g></svg> Back
                    </button>
                </div>
                <div className="menu-sec col-lg-7">            
                </div>
                <div className="save-download-logo-sec col-lg-3">    
                    <button title="Share" className="button btn-share-logo">
                        <img src="../assets/images/icon_share.svg" alt=""/>
                    </button>        
                    <button title="Save" className="button btn-save-logo">Save</button>
                    <button title="Download" className="button btn-download-logo"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="m11.25 15.85-4.38-4.38a.75.75 0 0 0-1.06 1.06l4.95 4.95c.69.68 1.8.68 2.48 0l4.95-4.95a.75.75 0 1 0-1.06-1.06l-4.38 4.38V4.25a.75.75 0 1 0-1.5 0v11.6zm-7.5 3.4h16.5a.75.75 0 1 1 0 1.5H3.75a.75.75 0 1 1 0-1.5z"></path></svg>Download</button>            
                </div>        
            </div>
        </header>



    </>
  )
}

export default DesignHeader
