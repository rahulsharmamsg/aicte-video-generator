import React from 'react'
import DesignLeftContainer from './DesignLeftContainer'
import DisplayItemsElement from './DisplayItemsElement'
import DisplayItemsBottom from './DisplayItemsBottom'
import DesignHeader from './DesignHeader'
import Canvas from './Canvas'




function ImageEditor() {
  return (
    <>
    <DesignHeader/>
       <div className="design-page-container">
            <div className="design-container">
                <div className="design-container-left">
                    <DesignLeftContainer/>                         
                </div>
                <div className="design-container-right">
                   
                    <DisplayItemsElement/>
                    <div className="design-frame-container">                        
                        <Canvas/>
                    </div>                    
                    <DisplayItemsBottom/>
                </div>
            </div>
        </div>
    </>
  )
}

export default ImageEditor
