import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const MannKiBat = () => {
  return (
    <>
      <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Translation</li>
            <li>Mann ki baat (100th episode celebration) Citizen feedback Form</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Mann ki baat (100th episode celebration) Citizen feedback Form</h1>
            <h3 className="second-head"></h3>
        </div>
    </div>
    <Safe/>
    <WhyChoose/>
    <Faq/>
    </>
  )
}

export default MannKiBat