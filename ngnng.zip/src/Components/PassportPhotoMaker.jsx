import React,{ useState } from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'
import { UploadSimple } from 'phosphor-react'
import originAL from "../assets/images/image/passport/3-change1.jpg"
import features from "../assets/images/image/passport/1-change1.jpg"
import img2 from "../assets/images/image/passport/5-change1.jpg"

const PassportPhotoMaker = () => {
    const [editor, setEditor] = useState(false);
    const [file, setFile] = useState();
    const openEditor = () =>{
        setEditor(true);
    }
const fileUpload = (e) =>{
    setFile(URL.createObjectURL(e.target.files[0]));
    if(e.target.files[0]){
        setEditor(true);
    }
}

  return (
    <>
       <div className="banner-allpage-sec" style={{paddingBottom:100}}>
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Image</li>
            <li>Passport Photo Maker</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Passport Photo Maker</h1>
            <h3 className="second-head">Fast, simple and easy to use tool you'll love. Anuvadini is the perfect online passport/visa/id photo maker, with proper sizes, e.g. 2’’x2’’, 4’’x6’’, etc.</h3>
            <br/>
           <div className='upload-btn-wrapper'>
           <Link to=""  className="button orange btn" style={{fontSize:26, borderRadius:10, padding:"15px 30px"}}>
            {/* <UploadSimple size={32} /> */}
                coming Soon...
            </Link>
            {/* <input type="file" name="myfile" onChange={fileUpload}/> */}
           </div>
            {/* <p className="txt-eg">or drop a file here CTRL+V to paste image or URL</p> */}
        </div>
    </div>
    {editor ? 
    <section style={{textAlign:"center", marginTop:-100, position:"relative"}}>
        <div className="page-container">
            <div className="originalResultDiv">
                <button type="button" aria-label="Close" className="clsoriginalResultDiv" onClick={()=> setEditor(!editor)}>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fillRule="evenodd" clipRule="evenodd" d="M4.818 4.05a.75.75 0 0 0-1.06 1.06l3.181 3.183-3.182 3.182a.75.75 0 1 0 1.061 1.06L8 9.355l3.182 3.182a.75.75 0 1 0 1.06-1.061L9.062 8.293l3.182-3.182a.75.75 0 0 0-1.061-1.06L8 7.231 4.818 4.05Z" fill="currentColor"></path>
                    </svg>
                </button>            
                <div className="row">
                    <div className="col-lg-4">
                        <h4>Original</h4>
                        <div className="imgDiv">
                            {/* <img src="./assets/images/upload/passport/original.png" crossorigin="anonymous" alt="original"/> */}
                            <img src={file} crossorigin="anonymous" alt="original"/>
                        </div>
                    </div>
                    <div className="col-lg-4">
                        <h4>Result</h4>
                        <div className="imgDiv">
                            <img src="./assets/images/upload/passport/result.png" alt="edit picture" oncontextmenu="return false" crossorigin="anonymous"/>
                        </div>
                    </div>
                    <div className="col-lg-4">
                        <div className="optRadioDiv">
                            <div className="optRadioRd">
                                <input checked="true" id="input-312" role="radio" type="radio" name="radio-311" value="PNG"/>
                                <label for="input-312" className="v-label theme--light">PNG</label>
                            </div>
                            <div className="optRadioRd">
                                <input  id="input-315" role="radio" type="radio" name="radio-311" value="PNG"/>
                                <label for="input-315" className="v-label theme--light">JPG</label>
                            </div>
                        </div>
                        <button className="button orange dwnLoadBtn">
                            <svg xmlns="http://www.w3.org/2000/svg" width="28px" height="28px" style={{rotate:"90deg", position:"relative", top:6}} fill="currentColor" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"></rect><polyline points="94 170 136 128 94 86" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="16"></polyline><line x1="24" y1="128" x2="136" y2="128" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="16"></line><path d="M136,40h56a8,8,0,0,1,8,8V208a8,8,0,0,1-8,8H136" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="16"></path></svg>
                            Download
                        </button>
                        <p className="txt-eg2">Preview Image 395 x 632, free</p>
                        <a href="/Editor/ImageEditor" className="txtOpenEdtr">
                            <img src="./assets/images/color-plate-svgrepo-com.svg" alt="" width="18px"/> Open in Editor
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    : null}
    <section style={{textAlign:"center", marginTop:-25, position:"relative"}}>
        <div className="secPassportPhotoImg">
            <img src={originAL} alt="window" width="480"/> 
            
        </div>
    </section>
    <section>
        <div className="page-container passportPhotoSection">
            <div className="features">
                <div className="margin">
                    <h2>Features</h2>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around align-items-center pb-5">
                                <div className="col-sm-12 col-md-6 col-12">
                                    <div className="relative" style={{maxWidth: "28.125rem"}}><img src={features} alt="" width="450" className="clearImg"/></div>
                                </div>
                                <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle"></p>
                                    <p className="chunkDescription">Remove background automatically and replace it with white background.</p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around align-items-center  pb-5">
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle"></p>
                                    <p className="chunkDescription">Combine standard passport, ID or VISA photos into single sheet of standard print paper sizes：3’’x4’’, 4’’x4’’, 4’’x6’’, 5’’x6’’ or A4.</p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative" style={{maxWidth: "28.125rem"}}><img src={img2} alt="" width="450" height="260" className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around align-items-center">
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative" style={{maxWidth: "28.125rem"}}><img src={originAL} alt="" width="450" height="260" className="clearImg"/></div>
                            </div>
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle"></p>
                                    <p className="chunkDescription">Portrait will be automatically resized, cropped and converted to perfect size with face centered.</p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    {/* <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle"></p>
                                    <p className="chunkDescription">Save as electronic image files: PNG with high quality or JPG with small file size.</p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative" style={{maxWidth: "28.125rem"}}><img src="https://d38b044pevnwc9.cloudfront.net/cutout-nuxt/passport/6-change1.jpg" alt="" width="450" height="260" className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div> */}
                    {/* <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative" style={{maxWidth: "28.125rem"}}><img src="https://d38b044pevnwc9.cloudfront.net/cutout-nuxt/passport/3-change1.jpg" alt="" width="450" height="260" className="clearImg"/></div>
                            </div>
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle"></p>
                                    <p className="chunkDescription">The astonishing passport suit changer with fashion for men and women allows you to choose a wide range of styles and templates of suit/outfit to experiment with.</p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div> */}
                    {/* <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle"></p>
                                    <p className="chunkDescription">Free preview and unbeatable price for purchase. Save time and money by DIY your own e-passport photo and have it printed at home or nearby</p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative" style={{maxWidth: "28.125rem"}}><img src="https://d38b044pevnwc9.cloudfront.net/cutout-nuxt/passport/7-change1.jpg" alt="" width="450" height="260" className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative" style={{maxWidth: "28.125rem"}}><img src="https://d38b044pevnwc9.cloudfront.net/cutout-nuxt/passport/4-change1.jpg" alt="" width="450" height="260" className="clearImg"/></div>
                            </div>
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle"></p>
                                    <p className="chunkDescription">Offer official photo sizes for ID, Passport, VISA and License of various countries including USA, Spain, Germany, France, India, China, Italy, Korea and Brazil: 2’’x2’’, 3’’x4’’, 4’’x4’’, 4’’x6’’, 5’’x6’’, etc.</p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div> */}
                </div>
                </div>
        </div>
    </section>
    <Safe/>
    <WhyChoose/>
    <Faq/>
    </>
  )
}

export default PassportPhotoMaker