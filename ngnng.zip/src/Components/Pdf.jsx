import React from 'react'
import { Link } from 'react-router-dom'
import svg1 from "../assets/images/icon/pdf/merge-pdf.svg?v=5ca75609"
import svg2 from "../assets/images/icon/pdf/split-pdf.svg?v=5ca75609"
import svg3 from "../assets/images/icon/pdf/compress-pdf.svg?v=5ca75609"
import svg4 from "../assets/images/icon/pdf/edit-pdf.svg?v=5ca75609"
import svg5 from "../assets/images/icon/pdf/sign-pdf.svg?v=5ca75609"
import svg6 from "../assets/images/icon/pdf/pdf-converter.svg?v=5ca75609"
import svg7 from "../assets/images/icon/pdf/images-to-pdf.svg?v=5ca75609"
import svg8 from "../assets/images/icon/pdf/pages-to-images.svg?v=5ca75609"
import svg9 from "../assets/images/icon/pdf/extract-images.svg?v=5ca75609"
import svg10 from "../assets/images/icon/pdf/protect-pdf.svg?v=5ca75609"
import svg11 from "../assets/images/icon/pdf/unlock-pdf.svg?v=5ca75609"
import svg12 from "../assets/images/icon/pdf/rotate-pdf-pages.svg?v=5ca75609"
import svg13 from "../assets/images/icon/pdf/remove-pdf-pages.svg?v=5ca75609"
import svg14 from "../assets/images/icon/pdf/extract-pdf-pages.svg?v=5ca75609"
import svg15 from "../assets/images/icon/pdf/sort-pdf-pages.svg?v=5ca75609"
import svg16 from "../assets/images/icon/pdf/webpage-to-pdf.svg?v=5ca75609"
import svg17 from "../assets/images/icon/pdf/create-job-application.svg?v=5ca75609"
import svg18 from "../assets/images/icon/pdf/scan-pdf.svg?v=5ca75609"
import svg19 from "../assets/images/icon/pdf/ocr-pdf.svg?v=5ca75609"
import svg20 from "../assets/images/icon/pdf/add-watermark-to-pdf.svg?v=5ca75609"
import svg21 from "../assets/images/icon/pdf/add-page-numbers-to-pdf.svg?v=5ca75609"
import svg22 from "../assets/images/icon/pdf/view-pdf.svg?v=5ca75609"
import svg23 from "../assets/images/icon/pdf/overlay-pdf.svg?v=5ca75609"
import svg24 from "../assets/images/icon/pdf/compare-pdf.svg?v=5ca75609"
import svg25 from "../assets/images/icon/pdf/web-optimize-pdf.svg?v=5ca75609"
import svg26 from "../assets/images/icon/pdf/annotate-pdf.svg?v=5ca75609"
import svg27 from "../assets/images/icon/pdf/blacken-pdf.svg?v=5ca75609"
import svg29 from "../assets/images/icon/pdf/convert-pdf-to.svg?v=5ca75609"
import svg30 from "../assets/images/icon/pdf/pages-to-images.svg?v=5ca75609"
function Pdf() {
    return (
        <>
            <div className="page-container">
                <div className="logo-maker-page">
                    <h2 className="text-center">PDF</h2>
                    <br />
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="pdfSection">
                                <ul>
                                    <li className="drop-menu-item">
                                        <Link to="/pdf/pdfeditor">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a">
                                                    <img src={svg1} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Merge PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item ">
                                        <Link to="/pdf/splitPDF"> 
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a">
                                                    <img src={svg2} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Split PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item ">
                                        <Link to="/pdf/pdfcompress">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a">
                                                    <img src={svg3} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Compress PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a">
                                                    <img src={svg4} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Edit PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a">
                                                    <img src={svg5} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Sign PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a">
                                                    <img src={svg6} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">PDF Converter</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a">
                                                    <img src={svg7} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Images to PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg8} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">PDF to images</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg9} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Extract PDF images</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg10} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Protect PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg11} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Unlock PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg12} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Rotate PDF pages</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg13} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Remove PDF pages</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg14} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Extract PDF pages</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg15} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Rearrange PDF pages</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    {/* <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg16} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Webpage to PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li> */}
                                    {/* <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg17} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Create PDF job application</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li> */}
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg18} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Create PDF with a camera</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg19} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">PDF OCR</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg20} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Add watermark</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg21} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Add page numbers</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg22} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">View as PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    {/* <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg23} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">PDF Overlay</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li> */}
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg24} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Compare PDFs</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    {/* <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg25} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Web optimize PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li> */}
                                    {/* <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg26} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Annotate PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li> */}
                                    {/* <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg27} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Redact PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li> */}
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg11} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">Create PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg29} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">PDF to Word</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                    <li className="drop-menu-item opctyNgryscle">
                                        <Link to="#!">
                                            <div className="css-hboir5">
                                                <div className="css-1hnxo7a" style={{ width: 75 }}>
                                                    <img src={svg30} alt="" />
                                                </div>
                                                <div className="css-195k0gj">
                                                    <div className="chakra-heading css-9f6g39">JPG to PDF</div>
                                                    <p className="chakra-text css-itvw0n"></p>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>




        </>
    )
}

export default Pdf