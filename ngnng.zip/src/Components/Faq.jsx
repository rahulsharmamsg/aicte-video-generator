import React from 'react'

const Faq = () => {
  return (
    <>
    {/* <div className="page-container" style={{maxWidth:900}}>        
        <section>
            <h2 className="text-center">The useful photo edit questions</h2>
            <h4 className="accordion">How to make passport photo?</h4>
            <div className="panel">
                <p>Take the perfect photo at home using your smartphone or choose the best photo from your cellphone album. With Single-Click to upload your photo onto cutout.pro, in One Second, your photo is ready. No need to download and install passport photo app or professional photo software such as photoshop. No need to manually resize/crop/adjust picture size or margin like traditional online digital passport/visa photo editors.</p>
            </div>
            <h4 className="accordion">How to change passport suit?</h4>
            <div className="panel">
                <p>You don’t need to wear formal suit, we provide suit changer with a collection of HD quality women/men/girls/boys formal smart suits for passport or ID designs and style. Selecting your favorite outfit, you can experiment and test out all the suits. Make them as attractive as you could.</p>
            </div>
            <h4 className="accordion">How to print passport photo?</h4>
            <div className="panel">
                <p>Download passport photo PNG or JPG/JPEG file, then order prints from print service providers. Or, you can take your phone to local near photo print service providers and get it printed.</p>
            </div>
        </section>        
    </div>    */}
    </>
  )
}

export default Faq
