import { Link } from '@mui/material';
import React from 'react';
import { AiOutlineDownload, AiOutlineEye } from 'react-icons/ai';
import { useNavigate } from 'react-router-dom';

const PdfViewer = ({ pdfData }) => {
    const navigate = useNavigate();
    let pdfurl = JSON.parse(localStorage.getItem("outp"))
    console.log("dddddd", pdfData)



    const handleDownload = () => {
        // Remove any prefix (e.g., data:image/png;base64,) if it exists
        const cleanBase64Data = pdfData.replace(/^data:.*?;base64,/, '');

        // Create a Blob from the clean base64 data
        const byteCharacters = atob(cleanBase64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/octet-stream' });

        // Create a URL for the Blob and trigger the download
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        let val = Date.now()
        a.download = `${val}-merged-pdf.pdf`; // Specify the filename here
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };
    return (
        <div>


            <iframe src={`data:application/pdf;base64,${pdfData.replace(/^data:.*?;base64,/, '')}`} width="100%" height="400" title="Base64 Viewer" />
            <div className='d-flex justify-content-center btnGroups'>
                <button className='button orange' onClick={handleDownload} ><AiOutlineDownload size={20} /> Download </button>

                <button type="file" onClick={() => navigate(-0)} className="button green clickForOne margin-right: 10px; ">
                    <svg stroke="currentColor" fill="currentColor" strokeWidth="0" viewBox="0 0 512 512" focusable="false" className="chakra-icon css-13otjrl" aria-hidden="true" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="48" d="M244 400L100 256l144-144M120 256h292"></path></svg>
                    restart
                </button>
            </div>

        </div>
    );
};

export default PdfViewer;