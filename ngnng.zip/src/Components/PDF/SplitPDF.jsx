import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import {AiOutlineFileAdd, AiOutlineDownload,AiOutlineEye} from "react-icons/ai"
import {MdRestartAlt} from "react-icons/md"
import { useEffect } from 'react';

function SplitPDF() {
    const [splitPdf, setSplitPdf] = useState(null);
    const [split ,setSplit] = useState(0);
    const handleSplite= () =>{
        setSplit(true);
    }
    const scrollToTop = () => {
        window.scrollTo({
          top: 0,
          behavior: "smooth",
        });
      };
      useEffect(() => {
        return scrollToTop()
      }, [])
  return (
    <>
        <div className="banner-allpage-sec voice">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Pdf</li>
        </ul>
        <div className="banner-content-sec text-center" style={{ padding: "0px 0 50px" }}>
            <h1 className="first-head">Split PDF</h1>
        </div>
    </div>
    <h3 className="second-head" style={{ textAlign: "center", position: "relative", zIndex: "999", top: -135 }}> Split Your PDF file into multiple smaller files</h3>
    <br/>
    {(split == 0)? 
    <section style={{ textAlign: "center", position: "relative", marginTop: -120, }}>
        <div className='page-container'>
            <div style={{ border: "#ccc 2px dotted", marginTop: -120, zIndex: 0, position: "relative", borderRadius: 10, background: "#fff", padding: 50, width: "100%", margin: "auto" }}>
              <div className='upload-btn-wrapper'>
                <input type="file" style={{ fontSize: 26, borderRadius: 10, padding: "15px 30px" }} onChange={handleSplite} />
                <button className="button orange opnoriginalResultDiv" ><svg stroke="currentColor" fill="currentColor" strokeWidth="0" viewBox="0 0 512 512" focusable="false" className="chakra-icon css-13otjrl" aria-hidden="true" height="1em" width="1em" style={{ width: 30, height: 30, position: "relative", top: 0 }} xmlns="http://www.w3.org/2000/svg"><path fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="32" d="M320 367.79h76c55 0 100-29.21 100-83.6s-53-81.47-96-83.6c-8.89-85.06-71-136.8-144-136.8-69 0-113.44 45.79-128 91.2-60 5.7-112 43.88-112 106.4s54 106.4 120 106.4h56"></path><path fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="32" d="M320 255.79l-64-64-64 64m64 192.42V207.79"></path></svg>
                    Browse computer</button>
                    <p>or drop files here</p>
              </div>
            </div>
        </div>
        </section> 
        :""}
     {(split == 1)? 
        <section style={{ textAlign: "center", position: "relative", marginTop: -120, }}>
            <div className='page-container'>
                <div style={{ border: "#ccc 2px dotted", marginTop: -120, zIndex: 0, position: "relative", borderRadius: 10, background: "#fff", padding: 50, width: "100%", margin: "auto" }}>
                 <iframe src='http://localhost:3000/pdf/splitPDF'></iframe>
                 <div className='row align-items-center'>
                    <div className='col-12 col-sm-12 col-md-6 col-lg-6 text-start'>
                        <label htmlFor="pdf">Pages / PDF:</label>
                        <select name="pdf" id="pdf">
                            <option value="0">1</option>
                            <option value="1">2</option>
                            <option value="2">3</option>
                        </select>
                    </div>
                
                 <div className='col-12 col-sm-12 col-md-6 col-lg-6'>
                <div className='d-flex justify-content-end'>
                <div className='upload-btn-wrapper text-end d-block'>
                    <input type="file" style={{ fontSize: 26, width:"100%",zIndex:999, borderRadius: 10, padding: "15px 30px" }} onChange={handleSplite} />
                    <button className="button green opnoriginalResultDiv" ><AiOutlineFileAdd size={20}/>Add</button>                    
                </div>
                <button className='button orange ml-3' onClick={()=>setSplit(2)}>Split</button>
                </div>
                </div>
                </div>
                </div>
                </div>
           
        </section> 
        :""}
        {(split == 2)?
        <>
       <section style={{ textAlign: "center", position: "relative", marginTop: -120, }}>
            <div className='page-container'>
                <div style={{ border: "#ccc 2px dotted", marginTop: -120, zIndex: 0, position: "relative", borderRadius: 10, background: "#fff", padding: 50, width: "100%", margin: "auto" }}>
                  <div className='btn-group'>
                    <button className='button orange'><AiOutlineDownload size={20}/>Download</button>
                    <button className='button green ml-3'><AiOutlineEye size={20}/>Preview</button>
                    <button className='button orange ml-3'><MdRestartAlt size={20}/>Restart</button>
                  </div>                
                </div>
            </div>
        </section> 
        </>
        :""}
    </>
  )
}

export default SplitPDF
