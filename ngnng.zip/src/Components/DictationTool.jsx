import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const DictationTool = () => {
  return (
    <>
     <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Translation</li>
            <li>Dictation Tool</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Dictation Tool</h1>
            <h3 className="second-head"></h3>
        </div>
    </div>
    <Safe/>
    <WhyChoose/>
    <Faq/>
    </>
  )
}

export default DictationTool