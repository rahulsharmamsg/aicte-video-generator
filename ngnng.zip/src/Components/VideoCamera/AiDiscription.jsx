import React,{useEffect,useState} from 'react'

import { Table } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { Progress } from 'react-sweet-progress';
import "react-sweet-progress/lib/style.css";
import ProgressBar from 'react-bootstrap/ProgressBar'


function AiDiscription() {

  const [response, setResponse]= useState()
  const [confidence, setconfidence]= useState()
  const [path, setpath]= useState()
  console.log(response,"8790-98790-98768908767890876578907")
  useEffect(() => {
    let data = JSON.parse(localStorage.getItem('reasponse'))
    setResponse(data.percentage)
    setpath(data.path)
    let percent = data.percentage?.percentage;
    console.log(percent,"jnsjsjj");
    setconfidence(Math.floor(percent));
  
  }, [])
 


  return (
    <>
    <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Video</li>
            <li>Branding</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">AI Video Analyzer</h1>
            <h3 className="second-head">Fast, simple and easy to use tool you'll love.</h3>
            <br/>            
            
        </div>
    </div>
      <main className="contentarea text-start">      
        <section className="selectLang mt-5">
          <div className="container">
            <div className="row" >
              <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                <div className="uploadvideo">            
                    <video width="320" height="240" src={`http://localhost:8090/${path}`} controls>
                        
                    </video>
                   
                </div>
              </div>
              <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                <div className="videoDetail">
                  
                   
                   
                  
                        {/* <div className="progress-bar bg-primary progress-bar-striped progress-bar-animated"
                        style={{width:'50%'}}>50%</div>
                        <br/>
                        <div className="progress-bar bg-success progress-bar-striped progress-bar-animated" 
                        style={{width:'90%'}}>90%</div>
                        <br/>
                        <div className="progress-bar bg-warning progress-bar-striped progress-bar-animated" 
                        style={{width:'30%'}}>30%</div>
                        <br/>
                        <div className="progress-bar bg-danger progress-bar-striped progress-bar-animated"
                        style={{width:'80%'}}>80%</div>
                        <br/>
                        <div className="progress-bar bg-info progress-bar-striped progress-bar-animated" 
                        style={{width:'70%'}}>70%
                        
                        </div>
                        <br/> */}
                 
                  
                  <Table responsive bordered striped hover>
                      <tbody>
                        <tr>
                          <th>Your Confidene Score</th>
                          <td>{confidence?confidence+'%':"NA"}</td>
                        </tr>
                        <tr>
                        <th>Confidence level</th>
                          {confidence>50&&confidence<=60?<th>Avarage</th>:confidence>60&&confidence<=75? <td>good</td>:confidence>75?<td>Very good</td>:<td>Below average</td>}
                          
                         
                        </tr>
                      </tbody>
                  </Table>
                  <ul>                    
                    <li className='d-flex justify-content-between'><span>😁</span> <Progress percent={Math.floor(response?.happy)}/></li>
                    <li className='d-flex justify-content-between'><span>😀</span> <Progress percent={Math.floor(response?.neutral)}/> </li>
                    <li className='d-flex justify-content-between'><span>☹️</span> <Progress percent={Math.floor(response?.angry)}/> </li>
                    <li className='d-flex justify-content-between'><span>😔</span> <Progress percent={Math.floor(response?.surprise)} /></li>
                    <li className='d-flex justify-content-between'><span>😔</span> <Progress percent={Math.floor(response?.fear)} /></li>
                    <li className='d-flex justify-content-between'><span>🥹</span> <Progress percent={Math.floor(response?.sad)} /></li>
                    <li className='d-flex justify-content-between'><span>😱</span> <Progress percent={Math.floor(response?.fear)} /></li>
                   </ul>
                </div>
              </div>
            </div>
          
          <div className="row mt-4">
            <div className="col-12 col-md-12 col-md-12 col-lg-12">
              <h3>Transcript</h3>
              <div className="videotext originalResultDiv mt-3">
                <p>
                  It is a long established fact that a reader will be distracted
                  by the readable content of a page when looking at its layout.
                  The point of using Lorem Ipsum is that it has a more-or-less
                  normal distribution of letters, as opposed to using 'Content
                  here, content here', making it look like readable English.
                </p>
              </div>
            </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}

export default AiDiscription;
