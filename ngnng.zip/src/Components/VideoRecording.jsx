import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const VideoRecording = () => {
  return (
    <>
    <div class="banner-allpage-sec">
        <ul class="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Meeting</li>
            <li>Video Recording</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Video Recording</h1>
            <h3 className="second-head">Create custom professional videos with Anuvadini's video recording feature. Enjoy a smooth recording experience with teleprompter and custom backgrounds on desktop and mobile.</h3>
        </div>
    </div>
    <section style={{textAlign:"center", marginTop:-100, position:"relative"}}>
        <div className="secPassportPhotoImg">
            <img src="./assets/images/video-recording/Camera Capture-1.png" alt="window" width="480"/>             
        </div>
    </section>
    <section>
        <div className="page-container passportPhotoSection">
            <div className="features">
                <div className="margin">
                    <h2>Create perfect recordings in minutes</h2>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                                <div className="col-sm-12 col-md-6 col-12">
                                    <div className="relative"><img src="./assets/images/video-recording/Create perfect recordings minutes-1.png" alt="" width="100%"  className="clearImg"/></div>
                                </div>
                                <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Add media</p>
                                    <p className="chunkDescription">Add videos and images to your recording to make your presentation more engaging.

</p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Select layout</p>
                                    <p className="chunkDescription">Choose from full-screen, side by side, and picture in picture options.</p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="./assets/images/video-recording/Create perfect recordings minutes-2.png" alt="" width="100%" className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="./assets/images/video-recording/Create perfect recordings minutes-3.png" alt="" width="100%" className="clearImg"/></div>
                            </div>
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Teleprompter</p>
                                    <p className="chunkDescription">Maintain eye contact while speaking fluently.</p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Multi-cam recording</p>
                                    <p className="chunkDescription">Add a second camera or connect your mobile device to be used as a document camera!</p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="./assets/images/video-recording/Create perfect recordings minutes-4.png" alt="" width="100%"  className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <br /><br /><br /><br />
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="./assets/images/video-recording/Camera Capture-1.png" alt="" width="100%" className="clearImg"/></div>
                            </div>
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Customize your recording</p>
                                    <p className="chunkDescription">
                                        <ul className="description-list"><li><p>Our intelligent camera recorder allows you to record your camera or add a second camera for multi-cam recording. What's more, you can even use your phone as a mobile camera for maximum versatility.</p></li><li><p>Adding still images and videos is simple, and customizing the layout while recording takes no time at all.</p></li><li><p>Customize your recording background by choosing a preset or uploading your own image.</p></li><li><p>Don’t want to show your camera background? Simply remove it or blur it out.</p></li></ul>
                                    </p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <br /><br /><br />
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                            <div className="flexCenter col-sm-12 col-md-5 col-12">
                                <div className="description">
                                    <p className="chunkTitle">Smooth recording experience</p>
                                    <p className="chunkDescription">
                                        <ul className="description-list"><li><p>With our built-in teleprompter feature, you can maintain eye-contact and speak at a comfortable pace.</p></li><li><p>No matter what platform you'd like to record on, desktop or mobile, the Anuvadini app is the perfect camera recorder to suit your needs.</p></li><li><p>Anuvadini makes capturing your footage easy and stress-free, so you can focus on creating high-quality content.</p></li></ul>
                                    </p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-12">
                                <div className="relative"><img src="./assets/images/video-recording/Camera Capture-2.png" alt="" width="100%"  className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
        </div>
    </section>
    <Safe/>
    <WhyChoose/>
    </>
  )
}

export default VideoRecording