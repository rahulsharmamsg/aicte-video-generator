import React from 'react'
import ic from "../assets/images/ic_social.svg";
import ic2 from "../assets/images/ic_folder.svg";
import ic3 from "../assets/images/ic_shirt.svg";
import ic4 from "../assets/images/ic_pen_tool.svg";
import ic5 from "../assets/images/ic_social.svg";
import ic6 from "../assets/images/ic_file.svg";

const WhyChoose = () => {
  return (
    <>
      {/* <div className="features-homepage-sec">
      <div className="page-container logo-maker-page">
        <h2 className="text-center">Why Choose ANUVADINI AI Tool</h2>
        <br/><br/><br/>
        <div className="row text-center why-choose-sec">
            <div className="col-lg-4">
                <div className="box">
                    <img src={ic} alt="" loading="lazy" height="100" width="100"/>
                    <h3>High Resolution Image</h3>
                    <p>Download your Image in high resolution for digital use or printing.</p>   
                </div>        
            </div>
            <div className="col-lg-4">
                <div className="box">
                    <img src={ic2} alt="" loading="lazy" height="100" width="100"/>
                    <h3>Image files</h3>
                    <p>SVG, PNG, EPS & PDF image files that let you scale your photo to any size.</p> 
                </div>          
            </div>
            <div className="col-lg-4">
                <div className="box">
                    <img src={ic3} alt="" loading="lazy" height="100" width="100"/>
                    <h3>Color variations</h3>
                    <p>Get black and white, colored, and transparent background variations of your photo, video, logo.</p> 
                </div>          
            </div>
            <div className="col-lg-4">
                <div className="box">
                    <img src={ic4} alt="" loading="lazy" height="100" width="100"/>
                    <h3>Print-Ready Files</h3>
                    <p>Print your photo anywhere from business cards to billboards.</p> 
                </div>          
            </div>
            <div className="col-lg-4">
                <div className="box">
                    <img src={ic5} alt="" loading="lazy" height="100" width="100"/>
                    <h3>Social Media Kit</h3>
                    <p>Use your photo, video, logo on all your social media channels eg. Facebook, Twitter, YouTube, and more.</p> 
                </div>         
            </div>
            <div className="col-lg-4">
                <div className="box">
                    <img src={ic6} alt="" loading="lazy" height="100" width="100"/>
                    <h3>Brand Guide</h3>
                    <p>Brand consistency is key. Get all the details about your photo, video, logo.</p> 
                </div>         
            </div>
        </div>
    </div>
</div> */}
    </>
  )
}

export default WhyChoose