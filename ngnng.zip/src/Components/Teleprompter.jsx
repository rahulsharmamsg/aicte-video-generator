import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const Teleprompter = () => {
  return (
    <>
         <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Meeting</li>
            <li>Teleprompter</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Teleprompter</h1>
            <h3 className="second-head">Record professional speeches with eye-contact using Visla's teleprompter tool. Script auto-scrolls at your preferred speed. Easy and free</h3>
        </div>
    </div>
    <section>
        <div className="page-container passportPhotoSection">
            <div className="features">
                <div className="margin">
                    <br/> <br/>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                                <div className="col-sm-12 col-md-6 col-12">
                                    <div className="relative"><img src="./assets/images/teleprompter/Teleprompter-1.png" alt="" width="100%" className="clearImg"/></div>
                                </div>
                                <div className="flexCenter col-sm-12 col-md-6 col-12">
                                    <div className="description">
                                        <p className="chunkTitle">Follow along the script</p>
                                        <p className="chunkDescription">
                                            <ul className="description-list"><li><p>Read from your script while recording using Visla’s teleprompter. Choose the size of the text and the speed at which the script will scroll to get a smooth video recording experience that best suits your preferences.</p></li><li><p>Simply copy paste or type in your script and follow the teleprompter as you start recording. You can also control the teleprompter by skipping to the previous or next line, or click on any line to jump to it.</p></li><li><p>Need to redo the recording? Reset the teleprompter back to the top and you can start all over again.</p></li></ul>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br/><br/><br/><br/>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                                <div className="flexCenter col-sm-12 col-md-6 col-12">
                                    <div className="description">
                                        <p className="chunkTitle">Maintain eye-contact while recording video</p>
                                        <p className="chunkDescription">
                                            <ul className="description-list"><li><p>With the help of the teleprompter, you can easily practice and record professional speeches while maintaining direct eye-contact with the camera!</p></li><li><p>No need for expensive teleprompter equipment, Visla’s video recorder can help you achieve the same experience for free. Record your presentations with consistent and accurate speech with our useful teleprompter tool. Don’t worry about forgetting your lines and just concentrate on speaking.</p></li></ul>
                                        </p>
                                    </div>
                                </div>
                                <div className="col-sm-12 col-md-6 col-12">
                                    <div data-v-022366bb="" className="relative"><img data-v-022366bb="" src="./assets/images/teleprompter/Teleprompter-2.png" alt="" width="100%" className="clearImg"/></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
        </div>
    </section>
    <Safe/>
    <WhyChoose/>
    <Faq/>
    </>
  )
}

export default Teleprompter