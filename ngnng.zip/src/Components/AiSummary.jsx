import React from "react";
import { Link } from "react-router-dom";
import { UploadSimple } from "phosphor-react";

const AiSummary = () => {
  return (
    <>
      <div className="banner-allpage-sec">
        <ul className="breadcrumb">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>Video</li>
          <li>AI Summary</li>
        </ul>
        <div className="banner-content-sec text-center">
          <h1 className="first-head">AI Summary</h1>
          <h3 className="second-head">
            Fast, simple and easy to use tool you'll love.
          </h3>
          <br />
          <Link
            to="/Editor/ImageEditor"
            className="button orange"
            style={{ fontSize: 26, borderRadius: 10, padding: "15px 30px" }}
          >
             <UploadSimple size={32} />
            Upload Video
          </Link>
          <p className="txt-eg">or drop a file here CTRL+V to paste image or URL</p>
        </div>
      </div>
      {/* <Safe/>
      <WhyChoose/>
      <Faq/> */}
    </>
  );
};

export default AiSummary;
