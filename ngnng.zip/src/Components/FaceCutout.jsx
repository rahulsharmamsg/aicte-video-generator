import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'
import face1 from "../assets/images/image/face/4.png"
import face2 from "../assets/images/image/face/leftss1-change.jpg"
import face3 from "../assets/images/image/face/rightss1-change1.jpeg"

const FaceCutout = () => {
  return (
    <> 
        <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Image</li>
            <li>Face Cutout</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Face Cutout</h1>
            <h3 className="second-head">Fast, simple and easy to use tool you'll love. Face and hair segmentation for adults, kids, and pets with hair-level fine details. <br/>Ready to be composited with cartoons,
printed on T-shirts, cell phone cases, etc.</h3>
            <br/>
            <Link to="" className="button orange btn" style={{fontSize:26, borderRadius:10, padding:"15px 30px"}}>
            {/* <UploadSimple size={32} /> */}
                Coming soon...
            </Link>
            
            {/* <p className="txt-eg">or drop a file here CTRL+V to paste image or URL</p> */}
        </div>
    </div>
    <section style={{textAlign:"center", marginTop:-50, position:"relative"}}>
        <div class="secFaceCutoutImg">
            <img src={face1} alt="window" width="380"/>             
        </div>
    </section>
    <section class="features-homepage-sec">
        <div class="page-container faceCutoutSection">
            <div class="row">
                <div class="col-sm-12 col-md-6 col-12">
                    <img data-v-3991f26a="" src={face2} alt="No need for green screens, remove background from real scene videos and replace with virtual background " class="clearImg"/>
                </div>
                <div class="flexCenter col-sm-12 col-md-5 col-12">
                    <div class="description">
                        <p class="chunkTitle">Big head cutout</p>
                        <p class="chunkDescription">Our featured bighead cutout is perfect for your next event. Whether it is a cardboard head cutout for a basketball team, a big head logo for a football team, or a customized big head for graduates, just upload portraits and get face cutouts instantly.</p>
                    </div>
                </div>
            </div>
            <br/><br/><br/><br/>
            <div class="row">                
                <div class="flexCenter col-sm-12 col-md-5 col-12">
                    <div class="description">
                        <p class="chunkTitle">Portraits, pets and cartoons</p>
                        <p class="chunkDescription">Snap your image and create a personalized giant face cutout. Whether it is an adult, a child, a cat, a dog, a Dutch rat, a Halloween vampire, or Santa Claus, you can easily generate a perfect big head cutout photo. Print on any item you can image. Make life, festivals, and celebrations more memorable.</p>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-12">
                    <img data-v-3991f26a="" src={face3} alt="Fully automatic,remove video background with only one click" class="clearImg"/>
                </div>
            </div>
            
        </div>
    </section>
    <Safe/>
    <WhyChoose/>
    {/* <Faq/> */}
    </>
  )
}

export default FaceCutout