import React from "react";
import { Link } from "react-router-dom";
import Faq from "./Faq";
import Safe from "./Safe";
import WhyChoose from "./WhyChoose";

const PhoneasWebcam = () => {
  return (
    <>
      <div className="banner-allpage-sec">
        <ul className="breadcrumb">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>Meeting</li>
          <li>Phone as Webcam</li>
        </ul>
        <div className="banner-content-sec text-center">
          <h1 className="first-head">Phone as Webcam</h1>
          <h3 className="second-head">
            Effortlessly link your mobile camera to your desktop to enjoy extra
            angles & versatile video recording. With Anuvadini's cable-free
            setup and QR code connection or Apple’s Continuity Camera,
            experience the convenience of using your phone as a webcam with
            Anuvadini today!
          </h3>
        </div>
      </div>
      <section
        style={{ textAlign: "center", marginTop: -70, position: "relative" }}
      >
        <div className="secPassportPhotoImg">
          <img
            src="./assets/images/phone-as-webcam/Connect Mobile as Camera-1.png"
            alt="window"
            width="480"
          />
        </div>
      </section>
      <section>
        <div className="page-container passportPhotoSection">
          <div className="features">
            <div className="margin">
              <br /> <br />
              <div className="moveChunk marginBto">
                <div className="margin">
                  <div className="row no-gutters justify-space-around">
                    <div className="col-sm-12 col-md-6 col-12">
                      <div className="relative">
                        <img
                          src="./assets/images/phone-as-webcam/Connect Mobile as Camera-1.png"
                          alt=""
                          width="100%"
                          className="clearImg"
                        />
                      </div>
                    </div>
                    <div className="flexCenter col-sm-12 col-md-6 col-12">
                      <div className="description">
                        <p className="chunkTitle">
                          Link Your Mobile Phone to Desktop as a Webca
                        </p>
                        <p className="chunkDescription">
                          <ul className="description-list">
                            <li>
                              <p>Easy cable-free setup</p>
                            </li>
                            <li>
                              <p>Scan a QR code to connect</p>
                            </li>
                            <li>
                              <p>
                                Automatically connect if already logged in to
                                the Anuvadini mobile app
                              </p>
                            </li>
                            <li>
                              <p>
                                Add an extra angle of yourself or something you
                                want to capture
                              </p>
                            </li>
                          </ul>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <br />
              <br />
              <br />
              <br />
              <div className="moveChunk marginBto">
                <div className="margin">
                  <div className="row no-gutters justify-space-around">
                    <div className="flexCenter col-sm-12 col-md-6 col-12">
                      <div className="description">
                        <p className="chunkTitle">
                          Take Advantage of Apple’s Continuity Camera Integratio
                        </p>
                        <p className="chunkDescription">
                          <ul className="description-list">
                            <li>
                              <p>
                                Utilize your iPhone camera and microphone on
                                your Mac
                              </p>
                            </li>
                            <li>
                              <p>
                                Integrate the Desk View camera without the need
                                for any third-party apps
                              </p>
                            </li>
                            <li>
                              <p>
                                Access all video effects for enhanced
                                creativity.
                              </p>
                            </li>
                          </ul>
                        </p>
                      </div>
                    </div>
                    <div className="col-sm-12 col-md-6 col-12">
                      <div className="relative">
                        <img
                          src="./assets/images/phone-as-webcam/Connect Mobile as Camera-2.png"
                          alt=""
                          width="100%"
                          className="clearImg"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Safe />
      <WhyChoose />
      <Faq />
    </>
  );
};

export default PhoneasWebcam;
