import React, { useState, useRef, useEffect } from 'react';
import Webcam from 'react-webcam';
import { useContext} from 'react';
import { AppContext } from '../context.js';
import {Progress} from 'react-sweet-progress'

function VideoRecorder({ video}) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordedChunks, setRecordedChunks] = useState([]);
  const [timer, settimer] = useState(100);
  const webcamRef = useRef(null);
  const mediaRecorderRef = useRef(null);

  const {setVideoData} = useContext(AppContext);

  

  const handleStartRecording = () => {
    setIsRecording(true);
    setRecordedChunks([]);
    Countdown()

    const stream = webcamRef.current.stream;
    mediaRecorderRef.current = new MediaRecorder(stream);

    mediaRecorderRef.current.ondataavailable = event => {
      if (event.data.size > 0) {
     
        setRecordedChunks(prevChunks => [...prevChunks, event.data]);
        // setVideoData(prevChunks => [...prevChunks, event.data]);
      }
    };

    mediaRecorderRef.current.start();
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      ShareData();

    }
  };

  const handleDownload = () => {
    const blob = new Blob(recordedChunks, { type: 'video/mp4' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    localStorage.setItem("recc",url)
    video=a
    a.style.display = 'none';
    a.href = url;
    a.download = 'recorded-video.mp4';
    document.body.appendChild(a);
    localStorage.setItem('recordedvideo',url)
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  const ShareData = () => {
    const blob = new Blob(recordedChunks, { type: 'video/mp4' });
    const url = URL.createObjectURL(blob);
    setVideoData(url);
 
     
  };
  const Countdown = () => {
    let i = 100;
    let interval = setInterval(() => {
        settimer(i)
        i--;
        if (i < 0) {
            clearInterval(interval);
            handleStopRecording()
        }
    }, 150);
  }
  
  
  

  // console.log(recordedChunks,"this is video Recording chunks")
  return (
    <div>
    
      <Webcam
        audio={false}
        mirrored={true}
        ref={webcamRef}
        videoConstraints={{ width: 1280, height: 720, facingMode: 'user' }}
      />
      
      {isRecording ? (<><Progress percent={timer} />
        <button className='button orange' onClick={handleStopRecording}>Stop Recording</button></>
      ) : (
        <button className='button green' onClick={handleStartRecording}>Start Recording</button>
      )}

      {recordedChunks.length > 0 && (
        <button className='button orange' style={{marginLeft:10}} onClick={handleDownload}>Upload Recording</button>
      )}
    </div>
  );
}

export default VideoRecorder;
