import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const GovtofIndiaSchemesAndInitiatives = () => {
  return (
    <>
    <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Translation</li>
            <li>Govt of India Schemes & Initiatives Voice Based Search (Chat GPT)</li>
        </ul>
        <div className="banner-content-sec text-center">
            <h1 className="first-head">Govt of India Schemes & Initiatives Voice Based Search (Chat GPT)</h1>
            <h3 className="second-head"></h3>
        </div>
    </div>
    <Safe/>
    <WhyChoose/>
    <Faq/>
    </>
  )
}

export default GovtofIndiaSchemesAndInitiatives