import React from 'react'
import { Link } from 'react-router-dom'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const RemoveCameraBackground = () => {
  return (
    <>
        <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Meeting</li>
            <li>Remove Camera Background</li>
        </ul>
        <div className="banner-content-sec text-center">
             <h1 className="first-head">Remove Camera Background</h1>
            <h3 className="second-head">Easily change your camera background with Visla. No green screen required. Customize with presets or upload your own image.</h3>
        </div>
    </div>
    <section>
        <div className="page-container passportPhotoSection">
            <div className="features">
                <div className="margin">
                    <br/> <br/>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                                <div data-v-022366bb="" className="col-sm-12 col-md-6 col-12">
                                    <div data-v-022366bb="" className="relative"><img data-v-022366bb="" src="./assets/images/remove-camera-background/Remove Camera Background-1.png" alt="" width="100%" className="clearImg"/></div>
                                </div>
                                <div className="flexCenter col-sm-12 col-md-6 col-12">
                                    <div className="description">
                                        <p className="chunkTitle">No more distracting backgrounds</p>
                                        <p className="chunkDescription">
                                            <ul className="description-list"><li><p>Easily remove your camera background by selecting the “Remove Background” option next to your camera preview.</p></li><li><p>No need for complex green screen set-ups. Instantly change your camera background and create professional-looking recordings with a customizable background. Easily separate the main video subject from the background, with or without a green screen.</p></li><li><p>Change your background to any color, choose from Visla presets, or upload your own image</p></li></ul>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br/><br/><br/><br/>
                    <div className="moveChunk marginBto">
                        <div className="margin">
                            <div className="row no-gutters justify-space-around">
                                <div className="flexCenter col-sm-12 col-md-6 col-12">
                                    <div className="description">
                                        <p className="chunkTitle">Green screen option</p>
                                        <p className="chunkDescription">
                                            <ul className="description-list"><li><p>If you have a green screen, simply select the “I have a green screen” option and the background removal effect will be more precise. You can also choose the color of your background to be removed if the detected color is inaccurate.</p></li><li><p>No need to move your computer around to find the perfect backdrop - you can change your background easily with Visla.</p></li><li><p>Effectively communicate your messages showing a clean, non-distracting background to make your recordings look more professional and create a better impression.</p></li></ul>
                                        </p>
                                    </div>
                                </div>
                                <div className="col-sm-12 col-md-6 col-12">
                                    <div className="relative"><img src="./assets/images/remove-camera-background/Remove Camera Background-2.png" alt="" width="100%" className="clearImg"/></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
        </div>
    </section>
    <Safe/>
    <WhyChoose/>
    <Faq/>
    </>
  )
}

export default RemoveCameraBackground