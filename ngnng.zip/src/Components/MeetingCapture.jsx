import { Link } from 'phosphor-react'
import React from 'react'
import Faq from './Faq'
import Safe from './Safe'
import WhyChoose from './WhyChoose'

const MeetingCapture = () => {
  return (
    <>
    <div className="banner-allpage-sec">
        <ul className="breadcrumb">
            <li><Link to="/">Home</Link></li>
            <li>Meeting</li>
            <li>Meeting Capture</li>
        </ul>
        <div className="banner-content-sec text-center">
        <h1 className="first-head">Meeting Capture</h1>
            <h3 className="second-head">Record your meetings, take notes, and extract highlights with Visla's optimized tool for video and meeting recording. Supports major platforms.</h3>
        </div>
    </div>
    <section style={{textAlign:"center", marginTop:-100, position:"relative"}}>
        <div className="secPassportPhotoImg">
            <img src="./assets/images/meeting-capture/MeetingCapture-7.png" alt="window" width="480"/>             
        </div>
        <div className="page-container passportPhotoSection">
            <div data-v-393d021e="" className="features">
                <div data-v-393d021e="" className="margin">
                    <h2 data-v-393d021e="">Capture your Meeting recordings in minutes</h2>
                    <br/> <br/>
                    <div data-v-3991f26a="" data-v-393d021e="" className="moveChunk marginBto">
                        <div data-v-3991f26a="" className="margin">
                            <div data-v-3991f26a="" className="row no-gutters justify-space-around">
                                <div data-v-3991f26a="" className="col-sm-12 col-md-6 col-12">
                                    <div data-v-3991f26a="" className="relative"><img data-v-3991f26a="" src="./assets/images/meeting-capture/MeetingCapture-1.png" alt="" width="100%"  className="clearImg"/></div>
                                </div>
                                <div data-v-3991f26a="" className="flexCenter col-sm-12 col-md-5 col-12">
                                <div data-v-3991f26a="" className="description">
                                    <p data-v-3991f26a="" className="chunkTitle">Make note of important meeting information</p>
                                    <p data-v-3991f26a="" className="chunkDescription">
                                        <ul className="description-list"><li><p>Support for major meeting platforms like Zoom, WebEx, Microsoft Teams, and Google Meet.</p></li><li><p>Record video, audio and screen sharing from all meeting participants.</p></li><li><p>Use text and emojis to take notes. Meeting notes kick in when you try to extract part of the content from your recording.</p></li></ul>
                                    </p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>=
                    <div data-v-022366bb="" data-v-393d021e="" className="moveChunk marginBto">
                        <div data-v-022366bb="" className="margin">
                            <div data-v-022366bb="" className="row no-gutters justify-space-around">
                            <div data-v-022366bb="" className="flexCenter col-sm-12 col-md-5 col-12">
                                <div data-v-022366bb="" className="description">
                                    <p data-v-022366bb="" className="chunkTitle">Take notes and extract highlights</p>
                                    <p data-v-022366bb="" className="chunkDescription">Visla provides an effective tool for recording your meetings, writing down meeting notes, and extracting highlights from these meetings, thereby increasing productivity by transforming long form contents into succinct snippets. What’s more -- Visla will automatically transcribe all the recorded clips.</p>
                                </div>
                            </div>
                            <div data-v-022366bb="" className="col-sm-12 col-md-6 col-12">
                                <div data-v-022366bb="" className="relative"><img data-v-022366bb="" src="./assets/images/meeting-capture/MeetingCapture-2.png" alt="" width="100%" className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div data-v-3991f26a="" data-v-393d021e="" className="moveChunk marginBto">
                        <div data-v-3991f26a="" className="margin">
                            <div data-v-3991f26a="" className="row no-gutters justify-space-around">
                            <div data-v-3991f26a="" className="col-sm-12 col-md-6 col-12">
                                <div data-v-3991f26a="" className="relative"><img data-v-3991f26a="" src="./assets/images/meeting-capture/MeetingCapture-3.png" alt="" width="100%" className="clearImg"/></div>
                            </div>
                            <div data-v-3991f26a="" className="flexCenter col-sm-12 col-md-5 col-12">
                                <div data-v-3991f26a="" className="description">
                                    <p data-v-3991f26a="" className="chunkTitle">Optimized for Video and Meeting Recording</p>
                                    <p data-v-3991f26a="" className="chunkDescription">Our meeting recorder does not join your meeting so you do not need to worry about your meeting participants seeing an uninvited guest inside the meeting. You can also take advantage of our meeting notes and extraction features to share highlight snippets from your meetings. Visla helps you easily repurpose recordings into shareable clips to to make team communications more efficient.</p>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div data-v-022366bb="" data-v-393d021e="" className="moveChunk marginBto">
                        <div data-v-022366bb="" className="margin">
                            <div data-v-022366bb="" className="row no-gutters justify-space-around">
                            <div data-v-022366bb="" className="flexCenter col-sm-12 col-md-5 col-12">
                                <div data-v-022366bb="" className="description">
                                    <p data-v-022366bb="" className="chunkTitle">Record any meeting</p>
                                    <p data-v-022366bb="" className="chunkDescription">Visla supports major meeting platforms like Zoom, WebEx, Microsoft Teams, and Google Meet. You can record video, audio and screen sharing from all meeting participants.</p>
                                </div>
                            </div>
                            <div data-v-022366bb="" className="col-sm-12 col-md-6 col-12">
                                <div data-v-022366bb="" className="relative"><img data-v-022366bb="" src="../assets/images/meeting-capture/MeetingCapture-4.png" alt="" width="100%"  className="clearImg"/></div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
        </div>
    </section>
    <Safe/>
    <WhyChoose/>
    </>
  )
}

export default MeetingCapture