import React, { useState } from "react";
import { Form, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import statelist from "../assets/Json/statedistrict.json";
function VideoForm() {
  let navigate = useNavigate();
  
  const [StKey, setStKey] = useState("");
  const [State, setState] = useState("");
  const [Uid, setUid] = useState();
  const [district, setdistrict] = useState();
  const [schoolname, setschoolname] = useState();
  const [stname, setstname] = useState();
  const [stnum, setstnum] = useState();
  const [stemail, setstemail] = useState();


  const handleSubmit = () => {
    console.log("state",State,Uid,schoolname,district)
    localStorage.setItem("videodata",JSON.stringify({State,Uid,schoolname,district,stname,stnum,stemail}))
    navigate("/AIVideoAnalyzer");
  };

  const handlestselect = (key) => {
    setStKey(key);
    setState(statelist.states[key].state)
  };

  return (
    <>
      <section className="slctState">
        <div className="container">
          <div className="selectstates originalResultDiv">
            <div className="subtittle text-center mb-4">
              <h3>AI Video Analyzer</h3>
            </div>
            <Form onSubmit={handleSubmit}> 
              <Form.Group className="mb-3">
                <Form.Label htmlFor="unique">Unique id</Form.Label>
                <Form.Control id="unique" placeholder="Unique id" onChange={(e)=>setUid(e.target.value)} />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label htmlFor="unique">Student Name</Form.Label>
                <Form.Control id="unique" placeholder="Name"  onChange={(e)=>setstname(e.target.value)}/>
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label htmlFor="unique">Student contact number</Form.Label>
                <Form.Control id="unique" placeholder="+91 ______..." maxLength={10}  onChange={(e)=>setstnum(e.target.value)}/>
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label htmlFor="unique">Student contact email</Form.Label>
                <Form.Control id="unique" placeholder="_____@___.com" type="e-mail"  onChange={(e)=>setstemail(e.target.value)}/>
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label htmlFor="StateSelect">Select State</Form.Label>
                <Form.Select
                  id="StateSelect"
                  className="form-control"
                  onChange={(e) => handlestselect(e.target.value)}
                >
                  <option>Select State</option>
                  {statelist.states.map((index, key) => (
                    <>
                      <option value={key}>{index.state}</option>
                    </>
                  ))}
                </Form.Select>
              </Form.Group>
              {StKey?<>   <Form.Group className="mb-3">
                <Form.Label htmlFor="DistrictSelect">
                  Select District
                </Form.Label>
                <Form.Select id="DistrictSelect" className="form-control" onClick={(e)=>setdistrict(e.target.value)}>
                  <option>Select District</option>
                  {statelist.states[StKey].districts.map(
                    (index) => (
                      <>
                        <option value={index}>{index}</option>
                      </>
                    )
                  )}
                </Form.Select>
              </Form.Group></>:<>   <Form.Group className="mb-3">
                <Form.Label htmlFor="DistrictSelect">
                  Select District
                </Form.Label>
                <Form.Select id="DistrictSelect" className="form-control" >
                  <option>Select District</option>
         
                </Form.Select>
              </Form.Group></>}
           
              <Form.Group className="mb-3">
                <Form.Label htmlFor="schoolname">School Name</Form.Label>
                <Form.Control id="schoolname" placeholder="School Name" onChange={(e)=>setschoolname(e.target.value)} />
              </Form.Group>
              <Form.Group className="mb-3 text-center">
                <Button
                 
                  type="submit"
                  className="button green"
                >
                  Submit
                </Button>
              </Form.Group>
            </Form>
          </div>
        </div>
      </section>
    </>
  );
}

export default VideoForm;
