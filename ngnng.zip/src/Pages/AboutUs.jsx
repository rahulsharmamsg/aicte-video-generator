import React from "react";
import Safe from "../Components/Safe";
import WhyChoose from "../Components/WhyChoose";
import image1 from "../assets/images/Dr-Anil-Sahasrabudhe.jpg";
import image2 from "../assets/images/Dr-T-G-Sitharam.jpg";
import image3 from "../assets/images/Dr-Chamu-Krishna-Shastry.jpg";
import image4 from "../assets/images/PROfILE-PIC.jpg";

const AboutUs = () => {
  return (
    <>
      <div className="banner-allpage-sec" style={{ paddingBottom: 70 }}>
        <div className="banner-content-sec text-center">
          <h1 className="page-heading">About Us</h1>
        </div>
      </div>
      <section className="abtText">
        <div className="container">
          <div className="abt text-start">
            <p>
              India has a rich & diverse lingual demographic, with 80% of the
              population identifying themselves as Non-English, Native Language
              speakers. A significant outcome of this regional diversity is the
              challenge in delivering standardized and high quality educational
              content in a manner that is comprehensible to students with
              diverse regional languages being spoken. Further, within higher
              education hotspots in the country students coming from rich
              diverse cultural backgrounds experience barriers to communication
              owing to distinct languages spoken eventually constrains the
              extent of collaboration and innovation that students can be
              capable of. Similarly scope for cross country collaboration in
              research is constrained due to language.
            </p>
            <p>
              The ANUVADINI: Voice & Document AI Translation Tools consisting of
              a multitude of features and functionalities desires to close this
              gap arising due to language barriers. The tool has support for 22
              regional Indian & foreign languages helping break language
              barriers & unifying India and the World under the principles of Ek
              Bharat Shrestha Bharat and One Earth, One Family, One Future!
            </p>
            <p>
              While having its inception as a technology solution for providing
              equitable access to quality education, the use cases of the
              Anuvadini bouqeut of tools are numerous and evolving with expected
              impacts of smooth communication and information flow in the
              domains of External Relations, Agriculture, Commerce, Railways &
              Transport, Scientific Research and Innovation.
            </p>
            <p>
              Anuvadini presents a tremendous opportunity for national unity and
              effective communication across the country while celebrating
              linguistic diversity and history of the country.
            </p>
          </div>
        </div>
      </section>
    
        <div className="container">
          <div className="abt text-start">
            <p>
              To realize the policy envisioned in NEP-2020 in leveraging
              technology for teaching, learning, testing and translation and to
              infuse advanced digital technology in the field of education and
              instruction, the Anuvadini Foundation was established by Ministry
              of Education as a not-to-profit Section 8 company under the aegis
              of All India Council for Technical Education (AICTE) on 2nd August
              2023. A copy of the Certificate of Incorporation and License
              Granted by Registrar of Companies is annexed. The Board of
              Directors of the company are as under:-
            </p>
            <div className="row nmDrtrSc">
              <div className="col-lg-3">
                {" "}
                <img className="w-100" src={image1} />{" "}
                <div className="nmDrtr">
                 <h3> Dr. Anil Sahasrabudhe</h3>
                  <span>
                    Chairman, National Educational Technology Forum-AICTE</span>
                    <span>Ministry of Education – Ex-Officio Chairman, Anuvadini
                    Foundation
                  </span>{" "}
                </div>
              </div>
              <div className="col-lg-3">
                {" "}
                <img className="w-100" src={image2} />{" "}
                <div className="nmDrtr">
                 <h3> Dr. T.G. Sitharam{" "}</h3>
                  <span>
                    Chairman, All India Council of Technical Education (AICTE)
                  </span>{" "}
                </div>
              </div>
              <div className="col-lg-3">
                {" "}
                <img className="w-100" src={image3} />{" "}
                <div className="nmDrtr">
                 <h3> Dr. Chamu Krishna Shastry{" "}</h3>
                  <span>
                    Chairman, Bharatiya Bhasha Samiti (High Powered Committee
                    for Promotion of Indian Languages)
                  </span>{" "}
                </div>
              </div>
              <div className="col-lg-3">
                {" "}
                <img className="w-100" src={image4} />{" "}
                <div className="nmDrtr">
                 <h3> Dr. Buddha Chandrasekhar</h3>
                  <span>
                    Chief Coordinating Officer, AICTE </span><span>Ex-Officio CEO of
                    Anuvadini Foundation</span> 
                  {" "}
                </div>
              </div>
            </div>
          </div>
        </div>
      
      <Safe />
      <WhyChoose />
    </>
  );
};

export default AboutUs;
